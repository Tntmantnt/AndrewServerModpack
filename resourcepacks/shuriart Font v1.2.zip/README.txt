This resource pack makes use of my original shuriart™ font.
© 2025 by shureee.
Licensed under the CC-BY 4.0

It also includes the font DotGothic16.
© 2020 by Fontworks Inc.
Licensed under the SIL Open Font License 1.1
https://scripts.sil.org/OFL

The font has been modified and/or combined for use in a Minecraft resource pack.