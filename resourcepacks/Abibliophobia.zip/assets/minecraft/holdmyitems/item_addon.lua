local l = (bl and 1) or -1
local d = (bl and 1) or -0.5
local booksEnchanted = false

local books = {
    "minecraft:enchanted_book",
}

-- Enchanted glow for books
for _, id in ipairs(books) do
    if I:isOf(item, Items:get(id)) and I:isEnchanted(item, Items:get(id))  then
        booksEnchanted = true
        break
    end
end
    if booksEnchanted then
        particleManager:addParticle(particles,
            false,
            0.1 * d,
            0.1,
            0,
            0,
            0,
            0,
            10 * l,
            0,
            0,
            0,
            0,
            0,
            3,
            Texture:of("minecraft", "textures/custom/enchant_glow/glow.png"), "ITEM", hand, "SPAWN", "ADDITIVE", 0, 115)
    end