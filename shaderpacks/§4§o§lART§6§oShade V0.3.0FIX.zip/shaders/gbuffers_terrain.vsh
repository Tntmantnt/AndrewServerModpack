// ============================================================================
// TERRAIN VERTEX SHADER & FOLIAGE ANIMATION
// ============================================================================
#version 120

attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec2 mc_midTexCoord;

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/foliages.glsl"
#include "/lib/jitter.glsl"

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 normal; 
varying vec4 tangent;
varying vec4 viewPos;
varying vec2 lmcoord;
varying float material_id;
varying vec3 worldPos;
varying float vWindGust;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor = gl_Color;
    
    normal = normalize(gl_NormalMatrix * gl_Normal);
    tangent = vec4(normalize(gl_NormalMatrix * at_tangent.xyz), at_tangent.w);
    material_id = mc_Entity.x;

    // Foliage and wind animation.
    vec4 local_pos = gl_ModelViewMatrix * gl_Vertex;
    vec3 player_space_pos = (gbufferModelViewInverse * local_pos).xyz;
    vec3 absolute_world_pos = player_space_pos + cameraPosition;
    
    // Detect top vertices for plant bending.
    bool is_top_vertex = gl_MultiTexCoord0.y < mc_midTexCoord.y;
    int block_id = int(material_id) - 10000;
    
    // Precise 3D grass (fluff) detection using geometric normals.
    vec3 absN = abs(gl_Normal.xyz);
    float edgeX = min(fract(absolute_world_pos.x), 1.0 - fract(absolute_world_pos.x));
    float edgeY = min(fract(absolute_world_pos.y), 1.0 - fract(absolute_world_pos.y));
    float edgeZ = min(fract(absolute_world_pos.z), 1.0 - fract(absolute_world_pos.z));
    
    bool is_solid_X = (absN.x > 0.99) && (edgeX < 0.01);
    bool is_solid_Y = (absN.y > 0.99) && (edgeY < 0.01);
    bool is_solid_Z = (absN.z > 0.99) && (edgeZ < 0.01);

    // Flag 3D grass if it's block 15 and lacks perfectly flat walls.
    bool is_fluff = (block_id == 15) && !(is_solid_X || is_solid_Y || is_solid_Z);
	
    // Invert detection to isolate top fluff correctly.
    bool is_top_fluff = false;
    
    if (is_fluff) {
        if (is_top_vertex && edgeY < 0.1) is_top_fluff = true;
        if (!is_top_vertex && edgeY > 0.1) is_top_fluff = true;
    }

    vWindGust = 0.0;
    
    // Top of grass block.
    bool is_grass_block_top = (block_id == 15) && (gl_Normal.y > 0.5);
    bool apply_wind_light = false;
    
    // 3D grass and tall/short grass.
    if (is_top_fluff || block_id == 2 || block_id == 3 || block_id == 4) {
        apply_wind_light = true;
    }
    
    #if GRASS_BLOCK_WIND_LIGHT == 1
    if (is_grass_block_top) {
        apply_wind_light = true;
    }
    #endif

    #if ENABLE_WIND == 1
    if (apply_wind_light) {
        float wind_speed = 0.8;
        float constant_t = frameTimeCounter * wind_speed * float(FOLIAGE_WIND_SPEED_MULTIPLIER) * float(WIND_GLOBAL_SPEED);
        
        float angleRad = radians(float(WIND_BASE_ANGLE));
        vec2 wind_dir = vec2(sin(angleRad), cos(angleRad));
        float raw_noise = get_foliage_noise_val(absolute_world_pos, wind_dir, constant_t, float(FOLIAGE_NOISE_SCALE));
        
        vWindGust = smoothstep(0.4, 0.7, raw_noise);
    }

    // Apply plant bending animation only if wind is enabled.
    absolute_world_pos = animate_vertex(absolute_world_pos, is_top_vertex, lmcoord.y, block_id, is_top_fluff);
    #endif

    player_space_pos = absolute_world_pos - cameraPosition;
    vec4 final_view_pos = gbufferModelView * vec4(player_space_pos, 1.0);
    
    viewPos = final_view_pos;
    worldPos = absolute_world_pos;
    gl_Position = gl_ProjectionMatrix * final_view_pos;
	
	// TAAJitter
    #if ENABLE_TAA == 1
    gl_Position.xy = TAAJitter(gl_Position.xy, gl_Position.w);
    #endif
}