// ============================================================================
// TEXTURED SKY AND HORIZON BLENDING
// ============================================================================
#version 120

uniform sampler2D texture;
varying vec2 texcoord;
varying vec4 glcolor;

varying vec3 worldDir;

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;

    // Soft circular mask to hide the quad's hard square edges.
    float dist = length(texcoord - vec2(0.5));
    // Very wide and soft gradient for a highly diffuse glow.
	float edgeFade = smoothstep(0.5, 0.1, dist);
    color.a *= edgeFade;

    // Discard strictly invisible pixels to optimize performance.
    if (color.a < 0.01) {
        discard;
    }
    
    // Smooth horizon clipping mask to blend textured skies softly.
    float horizonMask = smoothstep(0.0, 0.15, worldDir.y);
    color.a *= horizonMask;

    if (color.a <= 0.0) {
        discard;
    }
    
    /* DRAWBUFFERS:0 */
    gl_FragData[0] = color;
}