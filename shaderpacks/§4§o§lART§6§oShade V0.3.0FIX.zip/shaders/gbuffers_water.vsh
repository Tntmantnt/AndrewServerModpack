#version 120

attribute vec4 mc_Entity;
attribute vec4 at_tangent;

#include "/lib/uniforms.glsl"
#include "/lib/jitter.glsl"

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 normal; 
varying vec4 tangent;
varying vec4 viewPos;
varying vec2 lmcoord;
varying float material_id;
varying vec3 worldPos;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor = gl_Color;
    
    normal = normalize(gl_NormalMatrix * gl_Normal);
    tangent = vec4(normalize(gl_NormalMatrix * at_tangent.xyz), at_tangent.w);
    
    viewPos = gl_ModelViewMatrix * gl_Vertex;
    worldPos = (gbufferModelViewInverse * viewPos).xyz + cameraPosition;
    
    material_id = mc_Entity.x;
	
	// TAAJitter
    #if ENABLE_TAA == 1
    gl_Position.xy = TAAJitter(gl_Position.xy, gl_Position.w);
	#endif
}