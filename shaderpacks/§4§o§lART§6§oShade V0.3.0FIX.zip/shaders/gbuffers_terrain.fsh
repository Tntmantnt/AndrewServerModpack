// ============================================================================
// MAIN TERRAIN FRAGMENT SHADER
// ============================================================================
#version 120

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/sky.glsl"
#include "/lib/shadow_filter.glsl"
#include "/lib/fog.glsl"

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 normal; 
varying vec4 tangent;
varying vec4 viewPos;
varying vec2 lmcoord;
varying float material_id;
varying vec3 worldPos;
varying float vWindGust;

void main() {
    vec4 texColor = texture2D(gtexture, texcoord);
    vec4 albedo = vec4(texColor.rgb * glcolor.rgb, texColor.a);

    #if AMBIENT_OCCLUSION == 1
        // Interpolates between flat color and full vanilla AO.
        float ao_opacity = mix(1.0, glcolor.a, float(VANILLA_AO_INTENSITY));
        albedo.rgb *= ao_opacity; 
    #elif AMBIENT_OCCLUSION == 2
        // Custom ao will be implemented here.
    #endif
    
    // Discard fully transparent pixels immediately for performance.
    if (albedo.a < 0.1) discard;
    
    vec3 n = normalize(normal);
    
    // Transform normal to World Space to keep things stable when moving the camera.
    vec3 wNormal = normalize(mat3(gbufferModelViewInverse) * n);
    
    // Calculate eye-space sun direction.
    vec3 rawSunDir = normalize(sunPosition);
    // Transform sun direction to world space.
    vec3 worldSunDir = (gbufferModelViewInverse * vec4(rawSunDir, 0.0)).xyz;
    
    // Synchronize exact sun vector with OptiFine.
    vec3 l = worldSunDir.y > 0.0 ? rawSunDir : -rawSunDir;
    
    // Calculate surface illumination dot product.
    float NdotL = max(dot(n, l), 0.0);

    // Separate standard blocks from 3D fluff for precise foliage shading.
    bool is_plant = (abs(material_id - 10002.0) < 0.5 || abs(material_id - 10003.0) < 0.5 || abs(material_id - 10004.0) < 0.5);
	bool is_leaf = (abs(material_id - 10005.0) < 0.5);
    
    bool is_fluff_or_top = false;
    bool is_fluff = false; 
    
    if (abs(material_id - 10015.0) < 0.5) {
        // Detect block tops and standard flat grass.
        if (wNormal.y > 0.5) {
            is_fluff_or_top = true;
        }
        else {
            // Detect true 3D grass geometry.
            vec3 absN = abs(wNormal);
            float edgeX = min(fract(worldPos.x), 1.0 - fract(worldPos.x));
            float edgeY = min(fract(worldPos.y), 1.0 - fract(worldPos.y));
            float edgeZ = min(fract(worldPos.z), 1.0 - fract(worldPos.z));
            
            // Require mathematical perfection for solid walls to isolate slanted grass.
            bool is_solid_X = (absN.x > 0.99) && (edgeX < 0.01);
            bool is_solid_Y = (absN.y > 0.99) && (edgeY < 0.01);
            bool is_solid_Z = (absN.z > 0.99) && (edgeZ < 0.01);
            
            if (!(is_solid_X || is_solid_Y || is_solid_Z)) {
                is_fluff_or_top = true;
                is_fluff = true;
            }
        }
    }

    bool allow_grass_light = is_plant || is_fluff;
	
	// Calculate wetness for exposed upward faces.
    float surface_wetness = 0.0;
    #if ENABLE_RAIN_REFLECTIONS == 1
        float accelerated_wetness = clamp(wetness * 3.0, 0.0, 1.0);
        float adjusted_wetness = pow(accelerated_wetness, 1.0 / float(RAIN_PERSISTENCE));
        
        float wet_mask = (is_plant || is_fluff || is_leaf) ? 1.0 : clamp(wNormal.y, 0.0, 1.0);
        
        // Calculate wetness based on sky light and WORLD SPACE upward normal.
        surface_wetness = smoothstep(0.40, 0.90, lmcoord.y) * adjusted_wetness * wet_mask;
		
		// Fade out wetness in the distance to prevent white artifacts.
		surface_wetness *= 1.0 - smoothstep(32.0, 64.0, length(viewPos.xyz));
        
        bool is_non_porous = (abs(material_id - 10007.0) < 0.5) || (abs(material_id - 10009.0) < 0.5);
        
        float target_darkness = is_non_porous ? 1.0 : 0.65;
        
        // Darken porous materials when wet to simulate light absorption.
        albedo.rgb *= mix(1.0, target_darkness, surface_wetness);
    #endif
    
    #if GRASS_BLOCK_WIND_LIGHT == 1
    if (is_fluff_or_top) allow_grass_light = true;
    #endif

    if (allow_grass_light) {
        albedo.rgb *= float(GRASS_BASE_LIGHT);

        if (vWindGust > 0.0) {
            vec3 windHighlightTint = vec3(float(WIND_GUST_R), float(WIND_GUST_G), float(WIND_GUST_B));
            float gustFactor = clamp(vWindGust * float(WIND_GUST_INTENSITY), 0.0, 1.0);
            albedo.rgb = mix(albedo.rgb, albedo.rgb * windHighlightTint, gustFactor);
        }
    }

    #if PLANT_SHADING == 0
    if (is_plant || is_fluff_or_top) { NdotL = 1.0; }
    #elif PLANT_SHADING == 1
    if (is_plant) { NdotL = 1.0; }
    #endif

	// Convert to linear space and apply Albedo Fix.
    vec3 linearAlbedo = pow(albedo.rgb, vec3(2.2));
    linearAlbedo *= 0.35; // Match terrain albedo fix.

    // Fetch dynamic sun and ambient colors from library.
    vec3 lightSunColor, lightAmbColor;
    float currentShadowOpacity; 
    getLightColors(worldSunDir, lightSunColor, lightAmbColor, currentShadowOpacity);
    
    // Apply global dimming during rain.
    float lightDimmer = mix(1.0, float(RAIN_LIGHT_DIMMER), rainStrength);
    lightSunColor *= lightDimmer;
    lightAmbColor *= lightDimmer;

    float blockLight = lmcoord.x;
    float skyLight   = lmcoord.y;
    
    // Dynamic handheld light computation.
    #if HAND_DYNAMIC_LIGHTING == 1
        // Use player position for distance to ensure 3rd person consistency.
        float distToPlayer = length(worldPos - eyePosition);
        float handLight = clamp(1.0 - (distToPlayer / float(DYNAMIC_LIGHT_RADIUS)), 0.0, 1.0) * (float(heldBlockLightValue) / 15.0);
        blockLight = max(blockLight, handLight);
    #endif

    // =========================================================
    // Hard toon shadow mapping.
    // =========================================================
    float shadow = 1.0;
    
    #if ENABLE_SHADOWS == 1
        bool checkShadow = (NdotL > 0.0) || is_leaf; 
        
        if (checkShadow) {
            vec4 worldPosShadow = gbufferModelViewInverse * viewPos;

            if (is_leaf) {
                worldPosShadow.xyz += worldSunDir * 0.9;
            }

            vec4 shadowSpacePos = shadowModelView * worldPosShadow;
            shadowSpacePos = shadowProjection * shadowSpacePos;
            shadowSpacePos /= shadowSpacePos.w;
            
            float dist = length(shadowSpacePos.xy);
            float distortFactor = mix(1.0, dist, SHADOW_DISTORTION);
            shadowSpacePos.xy /= distortFactor;

            // Match shadow clip space z-scaling.
            shadowSpacePos.z /= 3.0;
            if (abs(shadowSpacePos.x) < 0.99 && abs(shadowSpacePos.y) < 0.99) {
                shadowSpacePos = shadowSpacePos * 0.5 + 0.5;
                float safeNdotL = is_leaf ? max(NdotL, 0.2) : NdotL;
                
                // Evaluate centralized hard shadow filter.
                shadow = getHardShadow(shadowtex0, shadowSpacePos.xyz, safeNdotL, distortFactor);
            }
        }
    #endif
    
    // Direct toon lighting and shadow opacity.
    float safeDirectLight = is_leaf ? max(NdotL, 0.0) : NdotL;
    float totalShadow = safeDirectLight * shadow;
    
    // Maintain minimum light intensity within shadows.
    float lightIntensity = mix(1.0 - currentShadowOpacity, 1.0, totalShadow);
    
    // Cave isolation to prevent daylight leaking.
    float skyLightCurve = pow(skyLight, float(CAVE_LIGHT_FALLOFF));
    float sunlightForce = lightIntensity * skyLightCurve;
    vec3 sunlightComp = linearAlbedo * lightSunColor * sunlightForce;

    // --- SSS (Subsurface Scattering) STYLISÉ (Type Zelda / Genshin) ---
    #if ENABLE_LEAVES_SSS == 1
    if (is_leaf) {
        vec3 v = normalize(-viewPos.xyz);
        
        float distortion = float(SSS_THICKNESS); 
        vec3 scatterDir = normalize(-l + n * distortion);
        
        float backlight = max(dot(v, scatterDir), 0.0);
        float sssFactor = pow(backlight, float(SSS_POWER));
        float viewDotNormal = max(dot(n, v), 0.0);
        
        // Restrict edge glow to backlit areas only.
        float edgeGlow = pow(1.0 - viewDotNormal, 2.0) * backlight;
        
        float totalSSS = (sssFactor + edgeGlow * 0.4) * float(SSS_INTENSITY);
        float canopyDepth = pow(lmcoord.y, 8.0);
        float sssShadow = shadow; 
        float transmission = 0.4 * canopyDepth; 
        float finalSSSMask = max(sssShadow, transmission);
        
        // Apply saturation only where SSS is strong.
        float luma = dot(albedo.rgb, vec3(0.299, 0.587, 0.114));
        vec3 saturatedAlbedo = mix(vec3(luma), albedo.rgb, float(SSS_SATURATION));
        vec3 sssColor = mix(albedo.rgb, saturatedAlbedo, clamp(totalSSS * finalSSSMask, 0.0, 1.0));
        
        vec3 sssLight = lightSunColor * totalSSS * finalSSSMask * skyLightCurve;
        vec3 translucentAlbedo = mix(sssColor, vec3(1.0), 0.4); 
        
        vec3 sssEmission = mix(sssColor * sssLight, translucentAlbedo * sssLight, clamp(totalSSS * finalSSSMask, 0.0, 1.0));
        
        // SSS Fade
        float distanceCam = length(viewPos.xyz);
        float sssFade = clamp((shadowDistance - distanceCam) / 16.0, 0.0, 1.0);
        sunlightComp += sssEmission * sssFade;
    }
    #endif
    
    // Apply sky ambient lighting based on exposure.
    vec3 skyAmbientComp = linearAlbedo * lightAmbColor * skyLightCurve;
    
    // Apply constant cave ambient lighting.
    vec3 caveBaseColor = vec3(CAVE_FOG_R, CAVE_FOG_G, CAVE_FOG_B);
    vec3 caveAmbientComp = linearAlbedo * caveBaseColor * float(MIN_CAVE_LIGHT) * (1.0 - skyLightCurve);
    
    // Combine sky and cave ambient lighting.
    vec3 ambientComp = skyAmbientComp + caveAmbientComp;

    float torchAttenuation = (blockLight * blockLight) * sqrt(blockLight);
    vec3 torchColor = vec3(TORCH_R, TORCH_G, TORCH_B) * TORCH_INTENSITY;
    vec3 torchIllumination = linearAlbedo * torchColor * torchAttenuation;
    
    vec3 finalColor = sunlightComp + ambientComp + torchIllumination;

    finalColor = pow(finalColor, vec3(1.0 / 2.2));

    // Unified fog application.
    float distance = length(viewPos.xyz);
    vec3 worldViewDir = normalize((gbufferModelViewInverse * vec4(normalize(viewPos.xyz), 0.0)).xyz);
    
    vec3 finalFogColor;
    float finalFogFactor;
    float borderFog; 
    
    // Calculate and apply fog using library.
    applyFog(distance, worldPos, worldViewDir, worldSunDir, skyLightCurve, rainStrength, far, lightSunColor, finalFogColor, finalFogFactor, borderFog);
    
    // Discard fragments completely hidden by border fog to prevent ghosting over clouds.
    if (borderFog < 0.001) {
        discard;
    }

    // 1. Apply global hue shift tint BEFORE fog.
    vec3 hueTint = vec3(HUE_SHIFT_R, HUE_SHIFT_G, HUE_SHIFT_B);
    vec3 normalizedTint = hueTint / max(dot(hueTint, vec3(0.333)), 0.001);
    finalColor = mix(finalColor, finalColor * normalizedTint, float(HUE_SHIFT_INTENSITY));

    // 2. Final color mixing (Fog must be applied LAST to match the sky perfectly).
    finalColor = mix(finalFogColor, finalColor, finalFogFactor);

    // Transmit signals for rim light, SSR, and bloom.
    float smoothness = 0.0;
    float reflective_strength = 0.0;
    float f0 = 0.0;
    float is_water = 0.0;

    // Identify blocks that should be excluded from Rim Light in mode 1 (No plants)
    bool is_rim_excluded = 
        (abs(material_id - 10002.0) < 0.5) || // Small plants
        (abs(material_id - 10003.0) < 0.5) || // Tall plants (lower)
        (abs(material_id - 10004.0) < 0.5) || // Tall plants (upper)
        (abs(material_id - 10005.0) < 0.5) || // Tree leaves
        (abs(material_id - 10008.0) < 0.5) || // Vines
        is_fluff_or_top;                      // Grass block top and 3D grass (block 10015)

    // We only need one flag now. We'll put it in the red channel of colortex3.
    float rim_exclusion_flag = is_rim_excluded ? 1.0 : 0.0;
    
    // Detect if block is emissive.
    bool is_emissive = (abs(material_id - 10010.0) < 0.5);
    
    // Luma thresholding for precise bloom detection.
    float luma = dot(albedo.rgb, vec3(0.299, 0.587, 0.114));
    
    // Create a smooth transition mask based on luminance threshold.
    float luma_mask = smoothstep(float(BLOOM_COLOR_DETECTION) - 0.2, float(BLOOM_COLOR_DETECTION) + 0.2, luma);
    
    // Combine emissive block ID with luminance mask.
    float emissive_flag = (is_emissive ? 1.0 : 0.0) * luma_mask;
    
    // Identify specific material types.
    bool is_metallic = (abs(material_id - 10007.0) < 0.5);
    bool is_polished = (abs(material_id - 10009.0) < 0.5);

    // Set base reflection values to trigger SSR.
    if (is_metallic) { 
        smoothness = 0.8;
        reflective_strength = 0.8; 
        f0 = 1.0; // Trigger metallic mix blend mode.
    } else if (is_polished) {
        smoothness = 0.7;
        reflective_strength = 0.6; 
        f0 = 0.0; // Trigger non-metallic additive blend mode.
    }

	// Trigger SSR and Specular dynamically on wet surfaces.
    float wetness_power = surface_wetness * float(RAIN_REFLECTION_STRENGTH);
    smoothness = max(smoothness, 0.85 * wetness_power);
    reflective_strength = max(reflective_strength, 0.7 * wetness_power);

    // =========================================================
    // PROCEDURAL SPECULAR
    // =========================================================
    #if ENABLE_SPECULAR == 1
        if (albedo.a > 0.9) {
            
            float lowBound = float(SPECULAR_DETECTION);
            float specStrength = float(SPECULAR_STRENGTH);

            // Override base values depending on the material type.
            if (is_metallic) {
                lowBound = float(SPECULAR_METALLIC_DETECTION);
                specStrength = float(SPECULAR_METALLIC_STRENGTH);
            } else if (is_polished) {
                lowBound = float(SPECULAR_POLISHED_DETECTION);
                specStrength = float(SPECULAR_POLISHED_STRENGTH);
            }

            // Detail mask based on detection threshold.
            float highBound = clamp(lowBound + 0.4, 0.0, 1.0);
            float detail_mask = smoothstep(lowBound, highBound, luma); 
            
            // Apply dynamic strength.
            float auto_spec = detail_mask * specStrength;
            
            vec3 viewDir = normalize(-viewPos.xyz);
            
            // Spread modifier.
            float spread = max(float(SPECULAR_PROPAGATION), 0.01);

            // 1. Direct Sun Specular (Blinn-Phong).
            vec3 halfDir = normalize(l + viewDir);
            float NdotH = max(dot(n, halfDir), 0.0);
            float sunShininess = 40.0 / spread;
            float sunSpecularHighlight = pow(NdotH, sunShininess) * auto_spec;
            float sunSpecularVisibility = sunSpecularHighlight * clamp(totalShadow, 0.0, 1.0);
            
            // Apply sun specular highlight.
            finalColor += lightSunColor * sunSpecularVisibility * 2.5 * finalFogFactor;

            // 2. Local Light Specular (Torches, Lava, Hand).
            float viewDotN = max(dot(n, viewDir), 0.0);
            float localFresnel = pow(1.0 - viewDotN, 2.5 / spread);
            float localLightFocus = pow(blockLight, 5.0 / spread);
            float localSpecularVisibility = localLightFocus * localFresnel * auto_spec;
            
            // Apply local light specular.
            finalColor += torchColor * TORCH_INTENSITY * localSpecularVisibility * 4.0 * finalFogFactor;

            // 3. Environmental SSR Signals.
            smoothness = clamp(max(smoothness, auto_spec * 0.7), 0.0, 1.0);
            reflective_strength = clamp(max(reflective_strength, auto_spec * 0.4), 0.0, 1.0);
        }
    #endif

    // Export packed light to restore rimlight illumination awareness.
    float lSky = clamp(skyLightCurve, 0.0, 1.0);
    float packedLight = floor(lSky * 15.0) * 16.0 + floor(clamp(blockLight, 0.0, 1.0) * 15.0);
    
    // Prevent negative colors to avoid NaN artifacts.
    finalColor = max(finalColor, vec3(0.0));
    
    /* DRAWBUFFERS:0123 */
    gl_FragData[0] = vec4(finalColor, albedo.a);
    gl_FragData[1] = vec4(n * 0.5 + 0.5, packedLight / 255.0);
    gl_FragData[2] = vec4(smoothness, reflective_strength, is_water, f0);
    
    // Pass rim exclusion in red, emissive in blue, wetness in alpha
    gl_FragData[3] = vec4(rim_exclusion_flag, 0.0, emissive_flag, surface_wetness);
}