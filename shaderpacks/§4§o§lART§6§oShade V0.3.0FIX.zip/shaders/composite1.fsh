// ============================================================================
// RIMLIGHT
// ============================================================================
#version 120

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/rimlight.glsl"
#include "/lib/sky.glsl"

varying vec2 texcoord;

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    
    #if ENABLE_RIM_LIGHT == 1 || ENABLE_RIM_LIGHT == 2
        vec2 texelSize = 1.0 / vec2(viewWidth, viewHeight);
        
        // Decode light map values.
        float packedLight = texture2D(colortex1, texcoord).a * 255.0;
        float blockL = mod(packedLight, 16.0) / 15.0;
        float sunL   = floor(packedLight / 16.0) / 15.0;
        blockL = pow(blockL, 2.0);
        
        float rimFactor = getRimLight(depthtex0, texcoord, texelSize, near, far);
		
		// Calculate absolute sun direction for fade masking.
		vec3 rawSunDir = normalize(sunPosition);
		vec3 worldSunDir = (gbufferModelViewInverse * vec4(rawSunDir, 0.0)).xyz;

		// Mute rim lighting during the OptiFine sun horizon jump.
		rimFactor *= getDirectionalFade(worldSunDir.y);
        
        // Read the plant exclusion flag from the red channel of colortex3.
        float is_plant_block = texture2D(colortex3, texcoord).r;
        
        // Reads the particle exclusion flag from the green channel.
        float is_particle = texture2D(colortex3, texcoord).g;

        // Mode 1: Block rim light on plants/leaves.
        #if ENABLE_RIM_LIGHT == 1
            if (is_plant_block > 0.5) {
                rimFactor = 0.0;
            }
        #endif
        
        // Forces rimlight to zero for particles in all modes.
        if (is_particle > 0.5) {
            rimFactor = 0.0;
        }
        
        float totalLight = clamp(sunL + blockL, 0.0, 1.0);
        rimFactor *= smoothstep(0.01, 0.15, totalLight);
        
        if (rimFactor > 0.0) {
            vec3 dynamicDirect, dynamicAmbient;
            float dummyShadowOpacity;
            getLightColors(worldSunDir, dynamicDirect, dynamicAmbient, dummyShadowOpacity);

            vec3 torchC = vec3(TORCH_R, TORCH_G, TORCH_B);
            
            // Mix dynamic lighting matching current time of day.
            vec3 baseLight = mix(dynamicAmbient, dynamicDirect, sunL);
            baseLight = mix(baseLight, torchC, blockL);
            
            vec3 tintedLight = mix(vec3(1.0), baseLight, RIM_COLOR_INFLUENCE);
            if (RIM_COLOR_INFLUENCE > 1.0) {
                tintedLight = pow(tintedLight, vec3(1.0 / RIM_COLOR_INFLUENCE));
            }
            
            vec3 textureColor = sqrt(max(color, vec3(0.0)));
            vec3 glowColor = textureColor * tintedLight * RIM_STRENGTH;
            
            // Apply screen-blend style rim light composite.
            color = 1.0 - (1.0 - color) * (1.0 - clamp(glowColor * rimFactor, 0.0, 1.0));
        }
    #endif

    // Prevent negative colors to avoid NaN artifacts.
    color = max(color, vec3(0.0));

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}