// ============================================================================
// SHADOW MAP VERTEX SHADER
// ============================================================================
#version 120

#include "/lib/settings.glsl"

attribute vec4 mc_Entity; 

uniform mat4 shadowModelViewInverse; 
uniform vec3 cameraPosition; 

varying vec2 texcoord;
varying vec4 glcolor;
varying float material_id;
varying float is_fluff_vertex; 

void main() {
    gl_Position = ftransform();
    
    // Apply shadow map distortion.
    float dist = length(gl_Position.xy);
    float distortFactor = mix(1.0, dist, SHADOW_DISTORTION);
    gl_Position.xy /= distortFactor;
    
    // Prevent tall shadows from clipping at a distance.
    gl_Position.z /= 3.0;
    
    texcoord = gl_MultiTexCoord0.xy;
    glcolor = gl_Color;
    material_id = mc_Entity.x; 

    // Calculate 3D grass parameters before distortion.
    vec4 local_pos = gl_ModelViewMatrix * gl_Vertex;
    vec3 worldPos = (shadowModelViewInverse * local_pos).xyz + cameraPosition;
    
    vec3 absN = abs(gl_Normal);
    float edgeX = min(fract(worldPos.x), 1.0 - fract(worldPos.x));
    float edgeY = min(fract(worldPos.y), 1.0 - fract(worldPos.y));
    float edgeZ = min(fract(worldPos.z), 1.0 - fract(worldPos.z));
    
    bool is_solid_X = (absN.x > 0.99) && (edgeX < 0.01);
    bool is_solid_Y = (absN.y > 0.99) && (edgeY < 0.01);
    bool is_solid_Z = (absN.z > 0.99) && (edgeZ < 0.01);
    
    // Send 1.0 flag to fragment if not a solid wall.
    is_fluff_vertex = !(is_solid_X || is_solid_Y || is_solid_Z) ? 1.0 : 0.0;
}