#version 120

attribute vec4 mc_Entity;
varying float material_id;
varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 normal; 
varying vec4 viewPos;
varying vec2 lmcoord;

uniform float viewWidth, viewHeight;
#include "/lib/jitter.glsl"

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor = gl_Color;
    normal = normalize(gl_NormalMatrix * gl_Normal);
    viewPos = gl_ModelViewMatrix * gl_Vertex;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
	
	// TAAJitter
    #if ENABLE_TAA == 1
    gl_Position.xy = TAAJitter(gl_Position.xy, gl_Position.w);
	#endif
	
	material_id = mc_Entity.x;
}