// ============================================================================
// TAA
// ============================================================================
#version 120

#include "/lib/uniforms.glsl"

varying vec4 color;
varying vec2 coord0;

// TAA
const bool colortex6Clear = false; 

void main()
{
    float temporalData = 0.0;
    vec3 temporalColor = texture2D(colortex6, coord0).rgb;

    // Prevent negative colors to avoid NaN artifacts.
    vec3 finalColor = max(color.rgb * texture2D(colortex0, coord0).rgb, vec3(0.0));

    /*DRAWBUFFERS:56*/
    gl_FragData[0] = vec4(finalColor, 1.0);
    gl_FragData[1] = vec4(temporalColor, temporalData);
}