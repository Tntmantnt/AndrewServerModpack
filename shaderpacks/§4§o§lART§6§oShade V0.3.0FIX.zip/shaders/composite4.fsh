// ============================================================================
// BLOOM VERTICAL PASS & COMPOSITING
// ============================================================================
#version 120

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"

varying vec2 texcoord;

float linearizeDepth(float d) {
    return (near * far) / (far - d * (far - near));
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

    #if ENABLE_BLOOM == 1
        float centerDepth = texture2D(depthtex0, texcoord).r;
        float dist = (centerDepth >= 1.0) ? 256.0 : linearizeDepth(centerDepth);
        float distScale = clamp(5.0 / max(dist, 0.5), 0.05, 5.0);
        
        vec2 direction = vec2(0.0, 1.0 / viewHeight);
        float max_radius = float(BLOOM_RADIUS) * 15.0 * distScale; 
        float stepDist = max_radius / float(BLOOM_STEPS);
        
        float sigma = float(BLOOM_STEPS) * 0.5;
        float sigmaSq2Inv = 1.0 / (2.0 * sigma * sigma);
        
        // Center sample extraction.
        vec3 bloom = texture2D(colortex4, texcoord).rgb;
        float totalWeight = 1.0; // exp(0) is exactly 1.0.
        
        // Fold the loop in half using Gaussian symmetry to save massive performance.
        for (int i = 1; i <= BLOOM_STEPS; i++) {
            float iF = float(i);
            float weight = exp(-(iF * iF) * sigmaSq2Inv);
            
            vec2 offsetUV = direction * (iF * stepDist);
            vec2 uv1 = clamp(texcoord + offsetUV, 0.001, 0.999);
            vec2 uv2 = clamp(texcoord - offsetUV, 0.001, 0.999);
            
            bloom += (texture2D(colortex4, uv1).rgb + texture2D(colortex4, uv2).rgb) * weight;
            totalWeight += weight * 2.0;
        }
        
        bloom /= totalWeight;
        
        // Apply user-defined bloom saturation.
        float luminance = dot(bloom, vec3(0.299, 0.587, 0.114));
        bloom = mix(vec3(luminance), bloom, float(BLOOM_COLOR_STRENGTH));
        
        // Prevent negative color values.
        bloom = max(bloom, 0.0);

        // Diminish bloom at screen edges to compensate for FOV.
        float distToCenter = length(texcoord - 0.5);
        float fovCompensator = smoothstep(0.8, 0.2, distToCenter); 
        bloom *= fovCompensator;

        // Final bloom is already weighted by intensities from composite3.
        vec3 finalBloom = bloom;

        // Apply soft additive blending for the final bloom.
        finalBloom = finalBloom / (1.0 + finalBloom); 

        color += finalBloom;
    #endif

    // Prevent negative colors to avoid NaN artifacts.
    color = max(color, vec3(0.0));

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}