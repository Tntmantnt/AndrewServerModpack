// ============================================================================
// WATER AND TRANSLUCENT BLOCKS FRAGMENT SHADER
// ============================================================================
#version 120

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/water.glsl"
#include "/lib/sky.glsl"
#include "/lib/shadow_filter.glsl"
#include "/lib/fog.glsl"

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 normal; 
varying vec4 tangent;
varying vec4 viewPos;
varying vec2 lmcoord;
varying float material_id;
varying vec3 worldPos;

void main() {
    // ========================================================================
    // MATERIAL INITIALIZATION
    // ========================================================================
    vec4 texColor = texture2D(gtexture, texcoord);
    vec4 albedo = vec4(texColor.rgb * glcolor.rgb, texColor.a);

    #if AMBIENT_OCCLUSION == 1
        // Interpolates between flat color and full vanilla AO.
        float ao_opacity = mix(1.0, glcolor.a, float(VANILLA_AO_INTENSITY));
        albedo.rgb *= ao_opacity; 
    #elif AMBIENT_OCCLUSION == 2
        // Custom ao will be implemented here.
    #endif
    
    vec3 outputNormal = normalize(normal);
    
    // Default PBR variables.
    float smoothness = 0.0;
    float reflective_strength = 0.0;
    float is_water = 0.0;
    float f0 = 0.0;
    float sparklesOut = 0.0; // Variable to store sparkle intensity

    // Restore reflections for polished blocks like ice.
    bool is_polished = (abs(material_id - 10009.0) < 0.5);

    if (is_polished) {
        smoothness = 0.7;
        reflective_strength = 0.6; 
        f0 = 0.0; 
        
        // Slightly increase opacity to hide water sparkles behind it.
        albedo.a = mix(albedo.a, 1.0, 0.8); 
    }
    // ========================================================================
    // WATER MATERIAL EXECUTION
    // ========================================================================
	
	// Calculate sun direction early to pass it to the water material.
    vec3 rawSunDir = normalize(sunPosition);
    vec3 worldSunDir = (gbufferModelViewInverse * vec4(rawSunDir, 0.0)).xyz;
	
    if (abs(material_id - 10006.0) < 0.5) {
        is_water = 1.0;
        smoothness = 1.0;
        
        vec2 screenUV = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
        vec3 viewDir = normalize(viewPos.xyz);
        float fresnel = 0.0;
        
        // Apply complex water material properties via centralized library.
        applyWaterMaterial(
            albedo, outputNormal, fresnel, sparklesOut,
            water, depthtex1, screenUV, gl_FragCoord.z, 
            worldPos, normal, tangent, viewDir, 
			worldSunDir,
            frameTimeCounter, near, far
        );
        reflective_strength = fresnel;
    }
    
    // ========================================================================
    // GLOBAL LIGHTING AND DIRECTION
    // ========================================================================
    vec3 l = worldSunDir.y > 0.0 ? rawSunDir : -rawSunDir;
    
    float NdotL = max(dot(outputNormal, l), 0.0);

    vec3 lightSunColor, lightAmbColor;
    float currentShadowOpacity;
    getLightColors(worldSunDir, lightSunColor, lightAmbColor, currentShadowOpacity);
    
    float lightDimmer = mix(1.0, float(RAIN_LIGHT_DIMMER), rainStrength);
    lightSunColor *= lightDimmer;
    lightAmbColor *= lightDimmer;
	
    float blockLight = lmcoord.x;
    float skyLight   = lmcoord.y;
	
	// Dynamic handheld light computation.
    #if HAND_DYNAMIC_LIGHTING == 1
        // Use player position for distance to ensure 3rd person consistency.
        float distToPlayer = length(worldPos - eyePosition);
        float handLight = clamp(1.0 - (distToPlayer / float(DYNAMIC_LIGHT_RADIUS)), 0.0, 1.0) * (float(heldBlockLightValue) / 15.0);
        blockLight = max(blockLight, handLight);
    #endif

    // ========================================================================
    // SHADOW MAPPING AND ILLUMINATION
    // ========================================================================
    float shadow = 1.0;

    #if ENABLE_SHADOWS == 1
        if (NdotL > 0.0) {
            vec4 worldPosShadow = gbufferModelViewInverse * viewPos;
            vec4 shadowSpacePos = shadowModelView * worldPosShadow;
            shadowSpacePos = shadowProjection * shadowSpacePos;
            shadowSpacePos /= shadowSpacePos.w;
            
            float dist = length(shadowSpacePos.xy);
            float distortFactor = mix(1.0, dist, SHADOW_DISTORTION);
            shadowSpacePos.xy /= distortFactor;
            shadowSpacePos.z /= 3.0;

            if (abs(shadowSpacePos.x) < 0.99 && abs(shadowSpacePos.y) < 0.99) {
                shadowSpacePos = shadowSpacePos * 0.5 + 0.5;
                shadow = getHardShadow(shadowtex0, shadowSpacePos.xyz, NdotL, distortFactor);
            }
        }
    #endif
    
    float totalShadow = NdotL * shadow;
    float lightIntensity = mix(1.0 - currentShadowOpacity, 1.0, totalShadow);
    
    float skyLightCurve = pow(skyLight, float(CAVE_LIGHT_FALLOFF));
    float sunlightForce = lightIntensity * skyLightCurve;
    
    // Converts to linear space and applies terrain-matching albedo fix.
    vec3 linearAlbedo = pow(albedo.rgb, vec3(2.2));
    linearAlbedo *= 0.35;
    
    vec3 sunlightComp = linearAlbedo * lightSunColor * sunlightForce;
    vec3 skyAmbientComp = linearAlbedo * lightAmbColor * skyLightCurve;
    
    vec3 caveBaseColor = vec3(CAVE_FOG_R, CAVE_FOG_G, CAVE_FOG_B);
    vec3 caveAmbientComp = linearAlbedo * caveBaseColor * float(MIN_CAVE_LIGHT) * (1.0 - skyLightCurve);
    
    vec3 ambientComp = skyAmbientComp + caveAmbientComp;
    vec3 torchColor = vec3(TORCH_R, TORCH_G, TORCH_B) * TORCH_INTENSITY * pow(blockLight, 2.5);
    
    vec3 finalColor = sunlightComp + ambientComp + linearAlbedo * torchColor;
    
    // Returns to sRGB space before applying fog.
    finalColor = pow(finalColor, vec3(1.0 / 2.2));
    
    // ========================================================================
    // FOG APPLICATION
    // ========================================================================
    float distance = length(viewPos.xyz);
    vec3 worldViewDir = normalize((gbufferModelViewInverse * vec4(normalize(viewPos.xyz), 0.0)).xyz);
    
    vec3 finalFogColor;
    float finalFogFactor;
    float borderFog;
    
    applyFog(distance, worldPos, worldViewDir, worldSunDir, skyLightCurve, rainStrength, far, lightSunColor, finalFogColor, finalFogFactor, borderFog);

    // Fade out sparkles in deep fog to prevent bright bloom.
    sparklesOut *= finalFogFactor;
    
    // Fade out SSR reflections in deep fog to prevent ghosting.
    reflective_strength *= finalFogFactor;

    if (borderFog < 0.001) discard;
    
    finalColor = mix(finalFogColor, finalColor, finalFogFactor);

    // ========================================================================
    // DATA PACKING AND EXPORT
    // ========================================================================
    float lSky = clamp(skyLightCurve, 0.0, 1.0);

    vec3 ssrNormal = normalize(mix(normal, outputNormal, 0.2)); 

    // Calculate the emission mask for translucent blocks.
    float luma = dot(albedo.rgb, vec3(0.299, 0.587, 0.114));
    float luma_mask = smoothstep(float(BLOOM_COLOR_DETECTION) - 0.2, float(BLOOM_COLOR_DETECTION) + 0.2, luma);
    bool is_emissive = (abs(material_id - 10010.0) < 0.5);
    float emissive_flag = (is_emissive ? 1.0 : 0.0) * luma_mask;

    // Combine translucent block emission with water sparkles.
    float final_bloom = max(emissive_flag, sparklesOut);

    // Prevent negative colors to avoid NaN artifacts.
    finalColor = max(finalColor, vec3(0.0));

    /* DRAWBUFFERS:0123 */
    gl_FragData[0] = vec4(finalColor, albedo.a);
    gl_FragData[1] = vec4(ssrNormal * 0.5 + 0.5, lSky);
    gl_FragData[2] = vec4(smoothness, reflective_strength, is_water, f0);
    
    // Additive blending preserves background bloom while applying new properties.
    gl_FragData[3] = vec4(1.0, 0.0, final_bloom, 0.0);
}