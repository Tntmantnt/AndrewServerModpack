// ============================================================================
// CELESTIAL BODIES VERTEX SHADER
// ============================================================================
#version 120

#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 worldDir;

void main() {
    vec4 pos = gl_Vertex;
    
    // Transform vertex to view space.
    vec3 viewPos = (gl_ModelViewMatrix * pos).xyz;

    // Determine if this is the Sun or the Moon based on direction.
    vec3 sunDir = normalize(sunPosition);
    bool isSun = dot(normalize(viewPos), sunDir) > 0.0;

    // Get the core direction of the celestial body.
    vec3 centerDir = isSun ? sunDir : -sunDir;

    // Project viewPos onto centerDir to find the quad's center in view space.
    float dist = dot(viewPos, centerDir);
    vec3 centerPos = centerDir * dist;

    // Extract the local offset of the vertex from the center.
    vec3 offset = viewPos - centerPos;

    // Apply scale to the offset.
    float scale = isSun ? float(SUN_SIZE) : float(MOON_SIZE);
    offset *= scale;

    // Apply custom tilt rotation around the center axis (sens inversé corrigé)
    float angle = -float(CELESTIAL_TILT);
    float s = sin(angle);
    float c = cos(angle);
    
    // Use simplified Rodrigues' rotation formula.
    vec3 rotatedOffset = offset * c + cross(centerDir, offset) * s;

    // Reconstruct the final transformed view position.
    vec3 finalViewPos = centerPos + rotatedOffset;

    gl_Position = gl_ProjectionMatrix * vec4(finalViewPos, 1.0);
    
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor = gl_Color;
    
    // Calculate absolute world direction for horizon clipping.
    worldDir = normalize((gbufferModelViewInverse * vec4(finalViewPos, 0.0)).xyz);
}