// ============================================================================
// SHADOW MAP FRAGMENT SHADER
// ============================================================================
#version 120

#include "/lib/settings.glsl"

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 glcolor;
varying float material_id;
varying float is_fluff_vertex;

void main() {
    vec4 albedo = texture2D(texture, texcoord) * glcolor;
    if (albedo.a < 0.1) {
        discard;
    }
    
    bool is_plant = (abs(material_id - 10002.0) < 0.5 || abs(material_id - 10003.0) < 0.5 || abs(material_id - 10004.0) < 0.5);
    
    // Apply grass rule using the intact vertex data.
    bool is_fluff = false;
    if (abs(material_id - 10015.0) < 0.5 && is_fluff_vertex > 0.5) {
        is_fluff = true;
    }

    #if PLANT_SHADING == 0
    if (is_plant || is_fluff) { discard; }
    #elif PLANT_SHADING == 1
    if (is_plant) { discard; }
    #endif
    
    gl_FragData[0] = albedo;
}