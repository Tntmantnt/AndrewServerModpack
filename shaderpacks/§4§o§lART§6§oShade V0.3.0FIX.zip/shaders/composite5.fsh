// ============================================================================
// SCREEN SPACE REFLECTIONS (SSR)
// ============================================================================
#version 120

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/sky.glsl"

// Fast spatial noise.
float getIGN(vec2 pos) {
    return fract(52.9829189 * fract(dot(pos, vec2(0.06711056, 0.00583715))));
}

varying vec2 texcoord;

vec3 projectAndDivide(mat4 projectionMatrix, in vec3 position) {
    vec4 position2 = projectionMatrix * vec4(position, 1.0);
    return position2.xyz / position2.w;
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    vec3 normals = texture2D(colortex1, texcoord).xyz * 2.0 - 1.0;
    vec4 pbr_data = texture2D(colortex2, texcoord);
    
    float smoothness = pbr_data.r;
    float reflective_strength = pbr_data.g;
    float is_water = pbr_data.b;
    float f0 = pbr_data.a;

    #if ENABLE_SSR == 1
    // Only calculate SSR if the player is above water.
    #if ENABLE_SSR_BLOCK == 1
    bool trigger_ssr = (smoothness * reflective_strength >= float(REFLECTION_THRESHHOLD)) || is_water > 0.5;
    #else
    bool trigger_ssr = is_water > 0.5; // Restrict SSR execution to water surfaces only.
    #endif

    // Only calculate SSR if the player is above water.
    if (isEyeInWater == 0 && trigger_ssr) {
        
        // Read smooth sky light directly from alpha channel.
        float skyLightAccess = texture2D(colortex1, texcoord).a;

        vec3 pos = vec3(texcoord, texture2D(depthtex0, texcoord).r) * 2.0 - 1.0;
        vec3 view_pos = projectAndDivide(gbufferProjectionInverse, pos);
        
        // Offset reflection ray to prevent self-intersection.
        view_pos += normals * 0.15;
        vec3 ray_spd = normalize(reflect(normalize(view_pos), normals));
        
        // Read rain factor from alpha channel.
        float rain_factor = texture2D(colortex3, texcoord).a;

        // Determine if blur applies based on material and rain settings.
        bool apply_blur = false;
        if (is_water > 0.5) {
            #if SSR_BLUR == 2 || SSR_BLUR == 3
                apply_blur = true;
            #endif
        } else {
            #if SSR_BLUR == 1 || SSR_BLUR == 2
                apply_blur = true;
            #endif

            // Toggle blur for rain puddles independently.
            #if RAIN_SSR_BLUR == 0
                if (rain_factor > 0.05) apply_blur = false;
            #endif
        }

        float ign = getIGN(gl_FragCoord.xy); 

		// Jitter 3D ray direction.
        if (apply_blur) {
            float temporal = fract(float(frameCounter % 16) * 0.6180339887);
            float dither = fract(ign + temporal);
            
            float angle = dither * 6.2831853;
            float r = sqrt(fract(dither + temporal)); 
            
            vec3 u = normalize(cross(ray_spd, vec3(0.0, 1.0, 0.0)));
            if (length(u) < 0.1) u = normalize(cross(ray_spd, vec3(1.0, 0.0, 0.0)));
            vec3 v = cross(ray_spd, u);
            
            // For water, we force a minimum roughness so the blur is visible.
            float roughness = (is_water > 0.5) ? 0.15 : (1.0 - smoothness);
            float scatter = float(SSR_BLUR_STRENGTH) * 0.05 * roughness; 
            
            ray_spd = normalize(ray_spd + (u * cos(angle) + v * sin(angle)) * r * scatter);
        }

        float f = 1.0;
        vec3 ray_screen_pos = vec3(0.0);
        
        bool hit = false;
        bool hit_sky = false; 
        bool oob = false;
        
        float max_trace_dist = 150.0;

        // Prevent ray from going behind the camera.
        vec3 end_view_pos = view_pos + ray_spd * max_trace_dist;
        if (end_view_pos.z > -0.1) {
            float dist = (-0.1 - view_pos.z) / min(ray_spd.z, -0.0001);
            end_view_pos = view_pos + ray_spd * max(dist, 0.0);
        }

        // Convert to Clip Space for straight 3D lines.
        vec4 startClip = gbufferProjection * vec4(view_pos, 1.0);
        vec4 endClip   = gbufferProjection * vec4(end_view_pos, 1.0);

        float current_progress = 0.0;

        for(float i = 1.0; i <= float(SSR_STEPS) && !hit && !oob; i++) {
            current_progress = i / float(SSR_STEPS);
            
            vec4 currentClip = mix(startClip, endClip, current_progress);
            ray_screen_pos = (currentClip.xyz / currentClip.w) * 0.5 + 0.5;
            
            oob = ray_screen_pos.x < 0.0 || ray_screen_pos.x > 1.0 ||
                  ray_screen_pos.y < 0.0 || ray_screen_pos.y > 1.0 || ray_screen_pos.z < 0.0 || ray_screen_pos.z > 1.0;
            if(oob) break;

            float scene_depth = texture2D(depthtex0, ray_screen_pos.xy).r;
            
            if (scene_depth >= 0.9999) {
                hit = true;
                hit_sky = true;
                break;
            }
            
            float depth_diff = ray_screen_pos.z - scene_depth;
            if(depth_diff > 0.0 && depth_diff < 0.025) {
                hit = true;
                break;
            }
        }
        
        vec3 reflection = vec3(0.0);
        float edge_fade = 1.0;
        
        if(hit) {
            vec3 final_hit_pos = ray_screen_pos;

            // Stable binary search.
            if (!hit_sky) {
                float min_prog = current_progress - (1.0 / float(SSR_STEPS));
                float max_prog = current_progress;
                float mid_prog;
                
                for(int rr = 0; rr < SSR_REFINEMENT_STEPS; rr++) { 
                    mid_prog = mix(min_prog, max_prog, 0.5);
                    vec4 mid_clip = mix(startClip, endClip, mid_prog);
                    vec3 mid_pos = (mid_clip.xyz / mid_clip.w) * 0.5 + 0.5;
                    
                    float scene_depth = texture2D(depthtex0, mid_pos.xy).r;
                    float depth_diff = mid_pos.z - scene_depth;
                    
                    if(depth_diff > 0.0) {
                        max_prog = mid_prog;
                    } else {
                        min_prog = mid_prog;
                    }
                }
                vec4 final_clip = mix(startClip, endClip, mid_prog);
                final_hit_pos = (final_clip.xyz / final_clip.w) * 0.5 + 0.5;
            }
            
            edge_fade = (is_water > 0.5) 
                ? clamp(min((1.0 - abs(final_hit_pos.x - 0.5) * 2.0) * 10.0, (1.0 - abs(final_hit_pos.y - 0.5) * 2.0) * 5.0), 0.0, 1.0)
                : clamp(min(1.0 - abs(final_hit_pos.x - 0.5) * 2.0, 1.0 - abs(final_hit_pos.y - 0.5) * 2.0), 0.0, 1.0);
            
            // Reconstruct hit position to apply a smooth distance fade.
            float hit_depth = texture2D(depthtex0, final_hit_pos.xy).r;
            vec3 hit_ndc = vec3(final_hit_pos.xy, hit_depth) * 2.0 - 1.0;
            float hit_dist = length(projectAndDivide(gbufferProjectionInverse, hit_ndc));
            
            // Use settings variables for the smoothstep fade.
            edge_fade *= 1.0 - smoothstep(far * float(SSR_BORDER_FADE_START), far * float(SSR_BORDER_FADE_END), hit_dist);

            // Single clean texture fetch, TAA handles the jitter blur.
            reflection = texture2D(colortex0, final_hit_pos.xy).rgb;
            
        } else {
            edge_fade = 0.0;
        }
        
        // Artificial sky fallback.
        vec3 worldRayDir = normalize((gbufferModelViewInverse * vec4(ray_spd, 0.0)).xyz);
        vec3 rawSunDir = normalize(sunPosition);
        vec3 worldSunDir = normalize((gbufferModelViewInverse * vec4(rawSunDir, 0.0)).xyz);

        vec3 zenithCol, horizonCol;
        getSkyColors(worldRayDir, worldSunDir, rainStrength, zenithCol, horizonCol);

        float skyHeight = max(worldRayDir.y, 0.0);
        float skyGradient = pow(skyHeight, float(SKY_GRADIENT));
        vec3 fallbackSky = mix(horizonCol, zenithCol, skyGradient);

        float sunDot = dot(worldRayDir, worldSunDir);
        float sunGlow = pow(max(sunDot, 0.0), float(SUN_GLOW_SPREAD)) * float(SUN_GLOW_POWER);
        
        vec3 dummyDirect, dummyAmbient; float dummyShadow;
        getLightColors(worldSunDir, dummyDirect, dummyAmbient, dummyShadow);
        fallbackSky += dummyDirect * sunGlow;

        fallbackSky *= skyLightAccess;
        reflection = mix(fallbackSky, reflection, edge_fade);

        // Aggressive metallic integration.
        if(f0 > 0.9) {
            reflection *= color * 1.5; 
        }
        
        // Dynamically boost block SSR opacity based on wetness.
        float wet_strength = max(float(SSR_BLOCK_STRENGTH), rain_factor * float(RAIN_REFLECTION_STRENGTH) * 0.6);
        float current_strength = (is_water > 0.5) ? float(SSR_STRENGTH) : wet_strength;
        
        // Smoothly fade in SSR opacity right after crossing the threshold to prevent pop-in.
        if (is_water < 0.5) {
            float reflect_val = smoothness * reflective_strength;
            float threshold = float(REFLECTION_THRESHHOLD);
            float fade_in = smoothstep(threshold, threshold + 0.40, reflect_val);
            current_strength *= fade_in;
        }
        
        // Apply global fade based on surface distance using settings defines.
        float view_dist = length(view_pos);
        current_strength *= 1.0 - smoothstep(far * float(SSR_BORDER_FADE_START), far * float(SSR_BORDER_FADE_END), view_dist);
        
        // Correct blend mode based on material.
        if (f0 > 0.9) {
            color = mix(color, reflection, current_strength);
        } else {
            color = mix(color, color + reflection, current_strength * f);
        }
    }
    #endif
        
    // Prevent negative colors to avoid NaN artifacts.
    color = max(color, vec3(0.0));

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}