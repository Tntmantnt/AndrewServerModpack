// ============================================================================
// BASIC GEOMETRY & BLOCK OUTLINE FRAGMENT SHADER
// ============================================================================
#version 120

varying vec4 glcolor;

void main() {
    if (glcolor.a < 0.01) discard;

    /* DRAWBUFFERS:0 */
    
    gl_FragData[0] = glcolor;
}