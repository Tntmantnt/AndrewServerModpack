// ============================================================================
// TEXTURE NOISES
// ============================================================================
#ifndef NOISES_GLSL
#define NOISES_GLSL

uniform sampler2D noisetex1;
uniform sampler2D noisetex2;
uniform sampler2D noisetex3;
uniform sampler2D noisetex4;
uniform sampler2D noisetex5;
uniform sampler2D noisetex6;

#endif