/*

const int colortex0Format  = RGBA16F;
//const int colortex1Format  = RGBA16F;
//const int colortex2Format  = RGBA16F;
//const int colortex3Format  = RGBA16F;
const int colortex4Format  = RGBA16F;
const int colortex5Format  = RGBA16F;
const int colortex6Format  = RGBA16F;
const bool colortex6Clear = false

*/