#ifndef SETTINGS_GLSL
#define SETTINGS_GLSL

// =========================================================================
// CREDITS
// =========================================================================
#define ABOUT 0 // [0]

// =========================================================================
// LIGHT
// =========================================================================

// --- SHADOWS ---
#define ENABLE_SHADOWS 1 // [0 1]
#define ENABLE_SMOOTH_SHADOWS 0 // [0 1]
const int shadowMapResolution = 2048; // [512 1024 2048 4096 8192]
const float shadowDistance = 128.0; // [48.0 64.0 96.0 128.0 192.0 256.0 512.0]
//const float shadowDistanceRenderMul = 1.0; // [1.0 2.0 3.0]
const float shadowMapBias = 0.9;
#define SHADOW_BIAS 0.001 // [0.001 0.002 0.003 0.004 0.005]
#define SHADOW_DISTORTION 0.90 // [0.70 0.80 0.85 0.90]
#define SHADOW_OPACITY 1.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Maximum shadow opacity.
#define SHADOW_ENTITY 1 // [0 1]
#define AMBIENT_OCCLUSION 1 // [0 1 2] // Set Ambient Occlusion mode (0: Off, 1: Vanilla, 2: Custom).
#define VANILLA_AO_INTENSITY 0.5 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// --- MAIN LIGHT ---
#define SUN_R 1.0 // [0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0 1.05 1.1 1.15 1.2 1.25 1.3 1.35 1.4 1.45 1.5]
#define SUN_G 0.95 // [0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0 1.05 1.1 1.15 1.2 1.25 1.3 1.35 1.4 1.45 1.5]
#define SUN_B 0.7 // [0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0 1.05 1.1 1.15 1.2 1.25 1.3 1.35 1.4 1.45 1.5]
#define MOON_R 0.025 // [0.0 0.01 0.025 0.05 0.075 0.1 0.125 0.15 0.175 0.2 0.25 0.3 0.35 0.4 0.45 0.5]
#define MOON_G 0.025 // [0.0 0.01 0.025 0.05 0.075 0.1 0.125 0.15 0.175 0.2 0.25 0.3 0.35 0.4 0.45 0.5]
#define MOON_B 0.025 // [0.0 0.01 0.025 0.05 0.075 0.1 0.125 0.15 0.175 0.2 0.25 0.3 0.35 0.4 0.45 0.5]
#define TORCH_R 1.0 // [0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4]
#define TORCH_G 0.8 // [0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4]
#define TORCH_B 0.5 // [0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4]
#define TORCH_INTENSITY 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0] // Artificial light intensity.
#define MIN_CAVE_LIGHT 0.1 // [0.0 0.025 0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0] // Minimum ambient light in caves.
#define CAVE_LIGHT_FALLOFF 3.0 // [1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0] // Underground sky light fade speed.
#define AMBIENT_INTENSITY 0.8 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0] // Day ambient light intensity.
#define AMBIENT_NIGHT_INTENSITY 0.3 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0] // Night ambient light intensity.
#define HAND_DYNAMIC_LIGHTING 1 // [0 1] // Enable dynamic handheld light.
#define DYNAMIC_LIGHT_RADIUS 10.0 // [5.0 10.0 15.0 20.0 25.0 30.0] // Max distance for handheld light.

// =========================================================================
// SKY
// =========================================================================

// --- SUNRISE ---
#define SUN_SUNRISE_R 1.0 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SUN_SUNRISE_G 0.5 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SUN_SUNRISE_B 0.35 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SUN_SUNRISE_SATURATION 2.0 // [0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8 3.0 3.2 3.4 3.6 3.8 4.0] // Sunrise sky saturation.
#define SUNRISE_END 0.8 // [0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0] // Sunrise start height.
#define SUNRISE_FADE_SPEED 2.5 // [1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3.0] // Sunrise fade speed.

// --- SKY_DAY ---
#define SKY_ZENITH_R 0.0 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_ZENITH_G 0.35 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_ZENITH_B 0.6 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_HORIZON_R 0.45 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_HORIZON_G 0.75 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SKY_HORIZON_B 0.9 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]

// --- SKY_NIGHT ---
#define SKY_NIGHT_ZENITH_R 0.0 // [0.0 0.0025 0.005 0.0075 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.11 0.12 0.13 0.14 0.15]
#define SKY_NIGHT_ZENITH_G 0.005 // [0.0 0.0025 0.005 0.0075 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.11 0.12 0.13 0.14 0.15]
#define SKY_NIGHT_ZENITH_B 0.01 // [0.0 0.0025 0.005 0.0075 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.11 0.12 0.13 0.14 0.15]
#define SKY_NIGHT_HORIZON_R 0.06 // [0.0 0.0025 0.005 0.0075 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.11 0.12 0.13 0.14 0.15]
#define SKY_NIGHT_HORIZON_G 0.08 // [0.0 0.0025 0.005 0.0075 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.11 0.12 0.13 0.14 0.15]
#define SKY_NIGHT_HORIZON_B 0.1 // [0.0 0.0025 0.005 0.0075 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.11 0.12 0.13 0.14 0.15]
#define NIGHT_START 0.15 // [0.2 0.175 0.15 0.125 0.1 0.075 0.05 0.025 0.0 -0.025 -0.05 -0.075 -0.1 -0.125 -0.15 -0.175 -0.2] // Night transition start.

// --- SUNSET ---
#define SUN_SUNSET_R 1.0 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SUN_SUNSET_G 0.45 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SUN_SUNSET_B 0.1 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define SUN_SUNSET_SATURATION 2.0 // [0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8 3.0 3.2 3.4 3.6 3.8 4.0] // Sunset sky saturation.
#define SUNSET_START 1.0 // [0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0] // Sunset start height.
#define SUNSET_FADE_SPEED 2.5 // [1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3.0] // Sunset fade speed.

// --- CELESTIAL ---
#define SUN_SIZE 0.5 // [0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3] // Sun texture size.
#define MOON_SIZE 0.8 // [0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3] // Moon texture size.
#define SUN_GLOW_POWER 0.5 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0] // Sun glow intensity.
#define MOON_GLOW_POWER 1.5 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0] // Moon glow intensity.
#define SUN_GLOW_SPREAD 40.0 // [5.0 10.0 20.0 40.0 50.0 60.0 70.0 80.0 90.0 100.0 110.0 120.0 130.0 140.0 150.0 160.0 170.0 180.0 190.0 200.0] // Sun glow spread.
#define MOON_GLOW_SPREAD 150.0 // [40.0 50.0 60.0 70.0 80.0 90.0 100.0 110.0 120.0 130.0 140.0 150.0 160.0 170.0 180.0 190.0 200.0] // Moon glow spread.
#define CELESTIAL_TILT 0.4 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0] // Celestial angle tilt in radians.

// --- MAIN SKY ---
#define SKY_GRADIENT 1.3 // [0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0] // Sky gradient height.
#define SUNRISESET_Y_OFFSET 0.7 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Twilight glow vertical offset.
#define SUNRISESET_SPREAD 2.5 // [1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5] // Twilight glow spread.
#define SUNRISESET_STRETCH 5.0 // [1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0 7.0 8.0 9.0] // Twilight glow horizontal stretch.
#define SUNRISESET_AMB_INTENSITY 0.8 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Twilight ambient light intensity.
#define SUNRISESET_LIGHT_MULTIPLIER 0.2 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5] // Twilight direct light multiplier.
#define SUNRISESET_LIGHT_SATURATION 0.5 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5] // Twilight light saturation.
#define SKY_PRESET 0 // [0 1 2] // Sky preset 0=Stylized(Default) 1=Realistic 2=Cartoon.

// =========================================================================
// FOG
// =========================================================================
#define FOG_DENSITY 0.003 // [0.0 0.0005 0.001 0.0015 0.002 0.0025 0.003 0.004 0.005 0.006 0.007 0.008 0.009 0.01 0.02 0.03 0.04 0.05] // Global fog density.
#define FOG_FALLOFF 1.5 // [0.2 0.5 0.8 1.0 1.2 1.5 1.8 2.0 2.5 3.0 3.5 4.0 4.5 5.0 5.5 6.0 6.5 7.0] // Fog distance falloff.
#define FOG_BRIGHTNESS 0.5 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0] // Brightness multiplier for base fog.
#define FOG_SATURATION 2.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.25 2.5 2.75 3.0] // Saturation multiplier for base fog.
#define CAVE_FOG_R 0.03 // [0.0 0.01 0.02 0.03 0.05 0.1 0.2]
#define CAVE_FOG_G 0.04 // [0.0 0.01 0.02 0.04 0.05 0.1 0.2]
#define CAVE_FOG_B 0.06 // [0.0 0.01 0.02 0.06 0.08 0.1 0.2]
#define ENABLE_BORDER_FOG 1 // [0 1] // Toggle distant border fog.
#define BORDER_FOG_START 0.5 // [0.2 0.3 0.4 0.5 0.6 0.7 0.75 0.8 0.85 0.9 0.95] // Border fog start distance.
#define BORDER_FOG_FALLOFF 3.0 // [0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0] // Border fog falloff curve.
#define BORDER_FOG_END 1.0 // [0.85 0.90 0.92 0.94 0.96 0.98 1.0] // Border fog end distance.

// =========================================================================
// POST_PROCESSING
// =========================================================================

// --- RIM_LIGHT ---
#define ENABLE_RIM_LIGHT 1 // [0 1 2] // Rim light mode (0: Off, 1: No plants, 2: All).
#define RIM_COLOR_INFLUENCE 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0]
#define RIM_THICKNESS 2.0 // [1.0 2.0 3.0 4.0 5.0]
#define RIM_STRENGTH 0.3 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define RIM_DEPTH_THRESHOLD 0.1 // [0.1 0.2 0.3 0.4 0.5 0.6 0.8 1.0]
#define RIM_MAX_DISTANCE 64.0 // [16.0 32.0 48.0 64.0 96.0 128.0]

// --- BLOOM ---
#define ENABLE_BLOOM 1 // [0 1]
#define OBJECT_BLOOM_INTENSITY 1.5 // [0.25 0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0]
#define GLOBAL_BLOOM_INTENSITY 0.5 // [0.25 0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0]
#define GLOBAL_BLOOM_THRESHOLD 1.0 // [0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0 1.05 1.1 1.15 1.2 1.25 1.3 1.35 1.4 1.45 1.5]
#define BLOOM_RADIUS 1.0 // [1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0]
#define BLOOM_STEPS 16 // [4 8 16 24 32]
#define BLOOM_COLOR_STRENGTH 2.0 // [0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 5.5 6.0 6.5 7.0 7.5 8.0 8.5 9.0 9.5]
#define BLOOM_COLOR_DETECTION 0.4 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8]

// --- GODRAYS ---
#define ENABLE_GODRAYS 1 // [0 1]
#define GODRAY_STEPS 24 // [4 8 16 24 32 48 64]
#define GODRAY_INTENSITY 1.0 // [0.2 0.4 0.6 0.8 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 6.0 7.0 8.0 9.0]
#define GODRAY_MAX_DISTANCE 64.0 // [16.0 32.0 48.0 64.0 96.0 128.0]
#define GODRAY_CONTRAST 6.0 // [1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0 7.0 8.0 9.0] // Godray outdoor fade contrast.
#define GODRAY_INDOOR_BOOST 10.0 // [1.0 2.0 3.0 4.0 5.0 6.0 8.0 10.0 20.0 30.0 40.0 50.0] // Godray indoor intensity boost.
#define GODRAY_OUTDOOR_MASK_START 0.6 // [0.3 0.4 0.5 0.6 0.7 0.8] // Outdoor fade start threshold.
#define GODRAY_OUTDOOR_MASK_END 0.85 // [0.6 0.7 0.8 0.85 0.9 0.95 1.0] // Outdoor fade end threshold.
#define GODRAY_DISTANCE_FADE_START 2.0 // [0.0 1.0 2.0 3.0 4.0 5.0] // Distance fade start.
#define GODRAY_DISTANCE_FADE_END 6.0 // [2.0 4.0 6.0 8.0 10.0 12.0] // Distance fade end.

// --- TONEMAP ---
#define TONEMAP_OPERATOR 2 // [0 1 2] // Tonemap operator (0: Vanilla, 1: ACES, 2: Reinhard-Jodie).
#define EXPOSURE 5.0 // [0.8 0.9 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 5.5 6.0 6.5 7.0 7.5 8.0 8.5 9.0 9.5 10.0 10.5 11.0 11.5 12.0 12.5 13.0 13.5 14.0 14.5 15.0]
#define GAMMA 0.8 // [0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0 1.05 1.1 1.15 1.2 1.25 1.3 1.35 1.4 1.45 1.5]
#define DARKNESS_DESATURATION 0.2 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Removes color from dark shadows.
#define SATURATION 1.0 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0 1.05 1.1 1.15 1.2 1.25 1.3 1.35 1.4 1.45 1.5 1.55 1.6 1.65 1.7 1.75 1.8 1.85 1.9 1.95 2.0]
#define VIBRANCE 1.0 // [0.0 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0 1.05 1.1 1.15 1.2 1.25 1.3 1.35 1.4 1.45 1.5 1.55 1.6 1.65 1.7 1.75 1.8 1.85 1.9 1.95 2.0]
#define TINT_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define TINT_G 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define TINT_B 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define TINT_INTENSITY 0.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define HUE_SHIFT_R 1.3 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5]
#define HUE_SHIFT_G 1.1 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5]
#define HUE_SHIFT_B 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5]
#define HUE_SHIFT_INTENSITY 0.6 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// --- ANTI-ALIASING ---
#define ENABLE_TAA 1 // [0 1]
#define SHARPENING 1 // [0 1]
#define SHARPEN_STRENGTH 0.1 // [0.025 0.05 0.075 0.1 0.125 0.15 0.175 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]

// =========================================================================
// CLOUDS
// =========================================================================
#define CLOUD_SKY_BLEND 0.7 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Cloud and sky blend strength.
#define CLOUD_BASE_DARKNESS 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Cloud base darkness.
#define CLOUD_SPEED_MULTIPLIER 1.75 // [1.0 1.25 1.5 1.75 2.0 2.25 2.5 2.75 3.0 3.25 3.5 3.75 4.0 4.25 4.5 4.75 5.0]
#define CLOUD_HEIGHT 192.0 // [128.0 160.0 192.0 224.0 256.0]
#define CLOUD_THICKNESS 8.0 // [2.0 4.0 8.0 12.0 16.0 24.0]
#define CLOUD_LAYER_SPACING 48.0 // [16.0 24.0 32.0 48.0]
#define CLOUD_DISTANCE 768.0 // [256.0 384.0 512.0 768.0 1024.0]
#define CLOUD_MORPH_SPEED 1.5 // [0.0 0.01 0.025 0.05 0.1 0.25 0.5 1.0 1.5 2.0 3.0 4.0 5.0]
#define CLOUD_SHORE 1.0 // [0.0 0.1 0.25 0.5 0.75 1.0 1.1 1.25 1.5 1.75 2.0] // Cloud edge softness.
#define CLOUD_NOISE_SMOOTHNESS 2.0 // [0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 10.0 15.0 20.0 25.0] // Cloud noise smoothness.
#define CLOUD_PIXEL_SIZE 4.0 // [1.0 2.0 4.0 8.0 12.0 16.0 24.0] // Cloud voxel size.
#define CLOUD_SMOOTH_DOWN 90.0 // [50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0] // Global Layer Opacity (Down)
#define CLOUD_SMOOTH_UP 75.0 // [50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0] // Global Layer Opacity (Up)
#define CLOUD_SUN_GLOW 1 // [0 1] // Enable sun scattering through clouds.
#define CLOUD_SUN_GLOW_POWER 0.75 // [0.5 0.75 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0] // Cloud sun glow intensity.
#define CLOUD_SUN_GLOW_SPREAD 8.0 // [2.0 4.0 8.0 12.0 16.0 24.0] // Cloud sun glow spread.
#define CLOUD_SUN_GLOW_SMOOTHNESS 0.8 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Glow diffusion smoothness.

// --- LAYER 1 ---
#define CLOUD_L1_COVERAGE 0.1 // [0.0 0.01 0.025 0.05 0.075 0.1 0.125 0.15 0.175 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.6] // Layer coverage.
#define CLOUD_L1_MIX 0.4      // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define CLOUD_L1_NOISE_1 2    // [1 2 3 4 5 6]
#define CLOUD_L1_NOISE_2 6    // [1 2 3 4 5 6]
#define CLOUD_L1_SCALE_1 0.1  // [0.025 0.05 0.1 0.25 0.5 1.0 2.0 4.0]
#define CLOUD_L1_SCALE_2 0.25  // [0.025 0.05 0.1 0.25 0.5 1.0 2.0 4.0]

// --- LAYER 2 ---
#define CLOUD_L2_COVERAGE 0.05 // [0.0 0.01 0.025 0.05 0.075 0.1 0.125 0.15 0.175 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.6] // Layer coverage.
#define CLOUD_L2_MIX 0.3 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define CLOUD_L2_NOISE_1 4 // [1 2 3 4 5 6]
#define CLOUD_L2_NOISE_2 5 // [1 2 3 4 5 6]
#define CLOUD_L2_SCALE_1 0.25 // [0.025 0.05 0.1 0.25 0.5 1.0 2.0 4.0]
#define CLOUD_L2_SCALE_2 0.1 // [0.025 0.05 0.1 0.25 0.5 1.0 2.0 4.0]

// --- LAYER 3 (Haut) ---
#define CLOUD_L3_COVERAGE 0.025 // [0.0 0.01 0.025 0.05 0.075 0.1 0.125 0.15 0.175 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.6] // Layer coverage.
#define CLOUD_L3_MIX 0.8 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define CLOUD_L3_NOISE_1 5 // [1 2 3 4 5 6]
#define CLOUD_L3_NOISE_2 6 // [1 2 3 4 5 6]
#define CLOUD_L3_SCALE_1 0.1 // [0.025 0.05 0.1 0.25 0.5 1.0 2.0 4.0]
#define CLOUD_L3_SCALE_2 0.1 // [0.025 0.05 0.1 0.25 0.5 1.0 2.0 4.0]

// =========================================================================
// WEATHER
// =========================================================================
#define WIND_BASE_ANGLE 45.0 // [0.0 45.0 90.0 135.0 180.0 225.0 270.0 315.0] // Base wind direction angle.
#define WIND_GLOBAL_SPEED 1.0 // [0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0]
#define WIND_BASE_ANGLE_VARIATION 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.25 2.5 2.75 3.0 3.25 3.5 3.75 4.0] // Wind variation frequency.

#define CLOUD_WIND_VARIATION_INTENSITY 15.0 // [0.0 5.0 10.0 15.0 20.0 30.0 50.0] // Cloud wind gust amplitude.
#define CLOUD_RAIN_COVERAGE 0.075 // [0.0 0.025 0.05 0.075 0.1 0.125 0.15 0.175 0.2 0.25 0.3 0.35 0.4 0.45 0.5] // Additional coverage during rain.
#define CLOUD_RAIN_DARKNESS 0.1 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8] // Cloud rain darkness.
#define CLOUD_RAIN_SPEED_MULTIPLIER 3.0 // [1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 5.5 6.0 6.5 7.0] // Cloud rain speed multiplier.

#define SKY_RAIN_COVERAGE 0.5 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Celestial coverage.
#define RAIN_TWILIGHT_MIX 0.3 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Twilight glow visibility during rain.
#define RAIN_LIGHT_DIMMER 0.5 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Celestial light rain dimmer.
#define GODRAY_RAIN_DIMMER 0.2 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Multiplier for godrays intensity during rain.

#define LEAVES_RAIN_INTENSITY_MULTI 0.25 // [0.0 0.1 0.2 0.25 0.5 0.75 1.0] // Rain wind multiplier for leaves.
#define FOLIAGES_RAIN_INTENSITY_MULTI 0.25 // [0.0 0.1 0.2 0.25 0.5 0.75 1.0] // Rain wind multiplier for plants.

#define SKY_RAIN_HORIZON_R 0.25 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65]
#define SKY_RAIN_HORIZON_G 0.3 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65]
#define SKY_RAIN_HORIZON_B 0.35 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65]
#define SKY_RAIN_NIGHT_HORIZON_R 0.02 // [0.0 0.01 0.02 0.03 0.04 0.05 0.1]
#define SKY_RAIN_NIGHT_HORIZON_G 0.03 // [0.0 0.01 0.02 0.03 0.04 0.05 0.1]
#define SKY_RAIN_NIGHT_HORIZON_B 0.05 // [0.0 0.01 0.02 0.03 0.04 0.05 0.1]

#define FOG_RAIN_MULTIPLIER 7.5 // [1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 5.5 6.0 6.5 7.0 7.5 8.0 8.5 9.0 9.5 10.0] // Multiplies fog density during rain.
#define FOG_RAIN_FALLOFF 1.0 // [1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 6.0] // Overrides fog falloff curve during rain.
#define BORDER_FOG_RAIN_START 0.0 // [0.0 0.1 0.2 0.25 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Border start distance during rain.
#define BORDER_FOG_RAIN_FALLOFF 0.5 // [0.1 0.2 0.25 0.3 0.4 0.5 0.6 0.8 1.0 1.5 2.0] // Border falloff curve during rain.

// --- RAIN WETNESS ---
#define ENABLE_RAIN_REFLECTIONS 1 // [0 1] // Enable wet ground reflections during rain.
#define RAIN_REFLECTION_STRENGTH 0.8 // [0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0] // Strength of the rain puddles.
#define RAIN_PERSISTENCE 1.5 // [0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0 4.0 5.0] // Adjusts how long puddles stay after rain.
#define RAIN_SSR_BLUR 1 // [0 1] // Enable blur on rain reflections.

// =========================================================================
// NATURE
// =========================================================================

// --- LEAVES ---
#define LEAVES_NOISE_TYPE 6 // [1 2 3 4 5 6]
#define LEAVES_NOISE_SMOOTHNESS 1.0 // [0.2 0.4 0.6 0.8 1.0 1.5 2.0 3.0 4.0 5.0] // Noise power curve.
#define LEAVES_WIND_INTENSITY 3.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0] // Base wind intensity for leaves.
#define LEAVES_NOISE_SCALE 1.0 // [0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0] // Leaf noise scale.
#define LEAVES_WIND_SPEED_MULTIPLIER 0.1 // [0.025 0.05 0.075 0.1 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0] // wind speed multiplier for leaves.
#define VINES_WIND_INTENSITY_DIVISOR 4.0 // [1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0] // Wind divisor for hanging vines.

// --- LEAVES SSS ---
#define ENABLE_LEAVES_SSS 1 // [0 1] // Enable Subsurface Scattering.
#define SSS_INTENSITY 1.0 // [0.5 0.75 1.0 1.25 1.5 1.75 2.0] // Subsurface Scattering Intensity.
#define SSS_POWER 10.0 // [1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0] // glow power.
#define SSS_THICKNESS 0.2 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6] // Wrap edge.
#define SSS_SATURATION 5.0 // [0.0 0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 5.5 6.0 6.5 7.0 7.5 8.0 8.5 9.0 9.5 10.0] // SSS color saturation.

// --- FOLIAGES ---
#define FOLIAGE_NOISE_TYPE 1 // [1 2 3 4 5 6]
#define FOLIAGE_NOISE_SMOOTHNESS 1.0 // [0.2 0.4 0.6 0.8 1.0 1.5 2.0 3.0 4.0 5.0] // Noise power curve.
#define FOLIAGE_WIND_INTENSITY 2.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0] // Base wind intensity for plants.
#define FOLIAGE_NOISE_SCALE 3.0 // [0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.25 2.5 2.75 3.0 3.25 3.5 3.75 4.0 4.25 4.5 4.75 5.0] // Plant noise scale.
#define FOLIAGE_WIND_SPEED_MULTIPLIER 0.75 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 5.0 10.0 15.0] // wind speed multiplier for plants.
#define FOLIAGE_BEND_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]

// --- WIND GUST LIGHTING ---
#define GRASS_BLOCK_WIND_LIGHT 1 // [0 1] // Wind light on grass block top.
#define GRASS_BASE_LIGHT 1.0 // [0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5] // Base grass light.
#define WIND_GUST_INTENSITY 0.2 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Wind light intensity.
#define WIND_GUST_R 1.5 // [1.25 1.5 1.75 2.0]
#define WIND_GUST_G 1.5 // [1.25 1.5 1.75 2.0]
#define WIND_GUST_B 1.5 // [1.25 1.5 1.75 2.0]

// --- PLAYER ---
#define PLAYER_INTERACTION 1 // [0 1]
#define PLAYER_INTERACTION_INTENSITY 0.75 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 5.0 10.0]
#define PLAYER_INTERACTION_RADIUS 0.75 // [0.75 1.0 1.25 1.5 1.75 2.0 2.5]

// --- MAIN NATURE ---
#define FOLIAGE_WIND_VARIATION_INTENSITY 10.0 // [0.0 2.0 5.0 10.0 15.0 20.0 30.0] // Foliage wind gust amplitude.
#define PLANT_SHADING 0 // [0 1 2] // Plant shadow mode (0: Off, 1: 3D Grass only, 2: All).
#define GRASS_3D_WIND 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // 3D grass wind intensity.
#define ENABLE_WIND 1 // [0 1] // Toggle wind animation globally.

// =========================================================================
// WATER
// =========================================================================

// --- TEXTURE ---
#define VANILLA_WATER_TEXTURE 0 // [0 1]
#define WATER_NORMALS 1.0 // [0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define WATER_SIZE 0.05 // [0.025 0.05 0.075 0.1 0.15 0.2 0.25 0.3]
#define WATER_SPEED 0.05 // [0.0 0.025 0.05 0.075 0.1 0.15 0.2 0.25 0.3]
#define WATER_WAVE_SHADING_STRENGTH 0.1 // [0.0 0.025 0.05 0.075 0.1 0.125 0.15 0.175 0.2] // Visibility of waves on water color.
#define WATER_WAVE_SHADING_HARDNESS 0.5 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Hardness of the shading edges (Cel-shading look).

// --- SPARKLES ---
#define WATER_SPARKLES 1 // [0 1]
#define WATER_SPARKLE_NOISE_1 5 // [1 2 3 4 5 6] // Texture map used for sparkles.
#define WATER_SPARKLE_NOISE_2 5 // [1 2 3 4 5 6]
#define WATER_SPARKLE_MIX 0.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define WATER_SPARKLE_DENSITY 0.1 // [0.025 0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.8 1.0] // Sparkle density.
#define WATER_SPARKLE_SCALE_1 3.0 // [0.5 0.6 0.7 0.8 0.9 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0] // Sparkle pattern scale.
#define WATER_SPARKLE_SCALE_2 3.0 // [0.5 0.6 0.7 0.8 0.9 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0] // Sparkle pattern scale.
#define WATER_SPARKLE_STRENGTH 0.6 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Sparkle light intensity.
#define WATER_SPARKLE_SMOOTHNESS 0.01 // [0.01 0.02 0.05 0.1 0.2 0.3 0.5] // Sparkle edge smoothness.
#define WATER_SPARKLE_FRACTURE 2.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0] // Sparkle fracture strength.
#define WATER_SPARKLE_DISTORTION 0.03 // [0.0 0.01 0.02 0.03 0.04 0.05] // Normal map sparkle distortion.
#define WATER_SPARKLE_NIGHT_MULTIPLIER 0.2 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Dim sparkles at night.
#define WATER_SPARKLE_SUN_INFLUENCE 0.5 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// --- SHORE ---
#define WATER_SHORE 1 // [0 1]
#define WATER_SHORE_NOISE_1 3 // [1 2 3 4 5 6] // Texture map used for shores.
#define WATER_SHORE_NOISE_2 2 // [1 2 3 4 5 6]
#define WATER_SHORE_MIX 0.4 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define WATER_SHORE_DISTANCE 1.25 // [0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0] // Shore foam distance.
#define WATER_SHORE_SCALE_1 2.0 // [0.5 0.6 0.7 0.8 0.9 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0] // Shore pattern scale.
#define WATER_SHORE_SCALE_2 2.0 // [0.5 0.6 0.7 0.8 0.9 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0] // Shore pattern scale.
#define WATER_SHORE_OPACITY 0.6 // [0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0] // Shore foam opacity.
#define WATER_SHORE_DISTORTION 0.05 // [0.0 0.01 0.02 0.03 0.04 0.05] // Normal map shore distortion.

// --- UNDERWATER ---
#define UNDERWATER_DEPTH_BRIGHTNESS 0.3 // [0.1 0.2 0.3 0.4 0.5 0.6 0.8 1.0] // Deep water brightness.
#define UNDERWATER_HORIZON_BRIGHTNESS 1.5 // [1.0 1.2 1.5 1.8 2.0 2.5 3.0] // Underwater horizon brightness.
#define UNDERWATER_BOTTOM_MULTIPLIER 0.5 // [0.1 0.2 0.3 0.4 0.5 0.6 0.8 1.0] // Underwater bottom darkening.
#define UNDERWATER_FOG_DENSITY 0.05 // [0.01 0.02 0.03 0.05 0.08 0.1 0.15 0.2] // Underwater fog density.
#define UNDERWATER_FOG_FALLOFF 0.0 // [0.0 1.0 1.5 2.0 2.5 3.0] // Curve of the underwater fog.
#define UNDERWATER_BORDER_FOG_END 0.15 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5] // Distance where the water becomes 100% opaque.
#define UNDERWATER_BORDER_FOG_FALLOFF 0.1 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5] // Hardness of the water wall.

// --- MAIN WATER ---
#define WATER_R 0.1 // [0.0 0.05 0.1 0.125 0.15 0.175 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.6 0.7 0.8 0.9 1.0]
#define WATER_G 0.3 // [0.0 0.05 0.1 0.125 0.15 0.175 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.6 0.7 0.8 0.9 1.0]
#define WATER_B 0.3 // [0.0 0.05 0.1 0.125 0.15 0.175 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.6 0.7 0.8 0.9 1.0]
#define WATER_A 0.9 // [0.0 0.05 0.1 0.125 0.15 0.175 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.6 0.7 0.8 0.9 1.0]
#define WATER_SURFACE_DARKNESS 0.8 // [0.2 0.4 0.6 0.7 0.8 1.0]
#define WATER_DEPTH_BRIGHTNESS 1.2 // [0.8 1.0 1.2 1.3 1.5 1.8 2.0]
#define WATER_PRESET 0 // [0 1]

// =========================================================================
// SSR & SPECULAR (pbr)
// =========================================================================
#define ENABLE_SSR 1 // [0 1]
#define SSR_STRENGTH 0.2 // [0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5]
#define ENABLE_SSR_BLOCK 1 // [0 1]
#define SSR_BLOCK_STRENGTH 0.2 // [0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5]
#define SSR_BLUR 1 // [0 1 2 3] // 0:Off, 1:Blocks, 2:Blocks+Water, 3:Water
#define SSR_BLUR_STRENGTH 3.0 // [0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0]
#define REFLECTION_THRESHHOLD 0.25 // [0.0 0.25 0.5 0.75]
#define FRESNEL_EXPONENT 3.0 // [1.0 3.0 6.0]
#define SSR_STEPS 30 // [5 10 20 30]
#define SSR_REFINEMENT_STEPS 3 // [0 1 2 3 4 5]
#define SSR_BORDER_FADE_START 0.3 // [0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9]
#define SSR_BORDER_FADE_END 0.6 // [0.4 0.5 0.6 0.7 0.8 0.8 0.9 0.95 1.0]

// --- PROCEDURAL SPECULAR ---
#define ENABLE_SPECULAR 1 // [0 1]
#define SPECULAR_PROPAGATION 1.5 // [0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.25 2.5 2.75 3.0 3.25 3.5 3.75 4.0 4.25 4.5 4.75 5.0]
#define SPECULAR_STRENGTH 0.05 // [0.025 0.05 0.075 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define SPECULAR_DETECTION 0.2 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8]
#define SPECULAR_METALLIC_STRENGTH 0.4 // [0.025 0.05 0.075 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define SPECULAR_METALLIC_DETECTION 0.7 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8]
#define SPECULAR_POLISHED_STRENGTH 0.3 // [0.025 0.05 0.075 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define SPECULAR_POLISHED_DETECTION 0.6 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8]

// =========================================================================
// MISC
// =========================================================================
// Enable RenoDX HDR pipeline. Requires rrtt217's HDR Mod.
#define HDR_ENABLED 0 // [0 1]
// Enable voxy compatibility
#define VOXY_PROFILE 0 // [0 1]
#if VOXY_PROFILE == 1
    #undef ENABLE_BORDER_FOG
    #define ENABLE_BORDER_FOG 0
    
    #undef FOG_DENSITY
    #define FOG_DENSITY 0.0015
	
	#undef FOG_FALLOFF
    #define FOG_FALLOFF 1.0
#endif


// =========================================================================
// STYLE PRESET
// =========================================================================
// --------- SKY PRESET ---------
#if SKY_PRESET == 1 // REALISTIC
    #undef SKY_ZENITH_R
    #define SKY_ZENITH_R 0.0
	
	#undef SKY_ZENITH_G
    #define SKY_ZENITH_G 0.25
	
	#undef SKY_ZENITH_B
    #define SKY_ZENITH_B 0.45
	
	#undef SKY_HORIZON_R
    #define SKY_HORIZON_R 0.75
	
	#undef SKY_HORIZON_G
    #define SKY_HORIZON_G 0.8
	
	#undef SKY_HORIZON_B
    #define SKY_HORIZON_B 0.85
#endif

#if SKY_PRESET == 2 // CARTOON
    #undef SKY_ZENITH_R
    #define SKY_ZENITH_R 0.0
	
	#undef SKY_ZENITH_G
    #define SKY_ZENITH_G 0.15
	
	#undef SKY_ZENITH_B
    #define SKY_ZENITH_B 0.4
	
	#undef SKY_HORIZON_R
    #define SKY_HORIZON_R 0.25
	
	#undef SKY_HORIZON_G
    #define SKY_HORIZON_G 0.55
	
	#undef SKY_HORIZON_B
    #define SKY_HORIZON_B 0.7
#endif

// --------- WATER PRESET ---------
#if WATER_PRESET == 1 // REALISTIC
    #undef WATER_R
    #define WATER_R 0.0
	
	#undef WATER_G
    #define WATER_G 0.05
	
	#undef WATER_B
    #define WATER_B 0.0
	
	#undef WATER_A
	#define WATER_A 1.0
	
	#undef WATER_SPARKLES
    #define WATER_SPARKLES 0
	
	#undef WATER_SHORE
    #define WATER_SHORE 0
	
	#undef SSR_STRENGTH
    #define SSR_STRENGTH 0.35
	
	#undef SSR_BLUR
    #define SSR_BLUR 2
#endif






#endif