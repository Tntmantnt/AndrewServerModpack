#ifndef UNIFORMS_GLSL
#define UNIFORMS_GLSL

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex6;
uniform sampler2D depthtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;

// Prevent redefinition errors when compiled by Voxy.
#ifndef VOXY_PROGRAM
uniform sampler2D depthtex1;
uniform sampler2D shadowtex0;
uniform sampler2D water;

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

uniform float viewWidth;
uniform float viewHeight;
uniform float near;
uniform float far;

uniform vec3 sunPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
#endif

uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;

uniform int frameCounter;
uniform int isEyeInWater;
uniform vec3 upPosition;

uniform ivec2 eyeBrightness;
uniform float aspectRatio;

uniform sampler2D gtexture;
uniform vec3 eyePosition;
uniform vec4 entityColor;
uniform int heldBlockLightValue;
uniform float wetness;
uniform int worldTime;

#endif