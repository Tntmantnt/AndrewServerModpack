// ============================================================================
// WEATHER AND WIND SYSTEM
// ============================================================================
#ifndef WEATHER_GLSL
#define WEATHER_GLSL

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"

// Calculate wind texture offset along the base angle.
vec2 getWindOffset(float localSpeed, float rainMultiplier, float variationAmplitude) {
    float t = frameTimeCounter;
    
    // VITESSE CONSTANTE : On ne multiplie plus par la pluie ici pour éviter le bond temporel !
    float constantSpeed = localSpeed * float(WIND_GLOBAL_SPEED);
    
    float angleRad = radians(float(WIND_BASE_ANGLE));
    vec2 baseDir = vec2(sin(angleRad), cos(angleRad)); 
    
    float varSpeed = float(WIND_BASE_ANGLE_VARIATION);
    float slowT = t * 0.02 * varSpeed;
    
    // TURBULENCE : L'effet de rafale peut garder le multiplicateur car il n'évolue pas vers l'infini.
    float currentIntensity = mix(1.0, rainMultiplier, rainStrength);
    float sway = sin(slowT * 1.3) * cos(slowT * 0.8);
    vec2 wandering = baseDir * sway * variationAmplitude * currentIntensity * constantSpeed;
    
    // Combine le mouvement constant et la turbulence
    return -((baseDir * t * constantSpeed) + wandering);
}

// Calculate instantaneous wind force vector.
vec2 getWindVector(float rainMultiplier, float variationAmplitude) {
    float t = frameTimeCounter;
    float currentForce = mix(1.0, rainMultiplier, rainStrength) * float(WIND_GLOBAL_SPEED);
    float angleRad = radians(float(WIND_BASE_ANGLE));
    
    vec2 baseDir = vec2(sin(angleRad), cos(angleRad)) * currentForce;
    
    float varSpeed = float(WIND_BASE_ANGLE_VARIATION);
    float slowT = t * 0.02 * varSpeed;
    
    // Apply same aligned sway logic to the vertex push force.
    float sway = cos(slowT * 1.3) * 1.3 - sin(slowT * 0.8) * 0.8;
    vec2 wanderingDir = baseDir * sway * variationAmplitude * 0.02 * varSpeed;
    
    return baseDir + wanderingDir;
}

#endif