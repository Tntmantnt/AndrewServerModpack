#version 120

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec4 viewPos;

void main() {
    gl_Position = ftransform();
    
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    
    glcolor  = gl_Color;
    viewPos = gl_ModelViewMatrix * gl_Vertex;
}