#version 120

varying vec3 viewVector;

void main() {
    gl_Position = ftransform();
    viewVector = (gl_ModelViewMatrix * gl_Vertex).xyz;
}