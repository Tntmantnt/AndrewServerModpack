// ============================================================================
// GODRAYS
// ============================================================================
#version 120

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/sky.glsl"

varying vec2 texcoord; 

float getAnimatedDither(vec2 pos, float time) {
    // Faster dither without mod() for better GPU pipelining.
    return fract(sin(dot(pos, vec2(12.9898, 78.233)) + time) * 43758.5453);
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

    #if ENABLE_GODRAYS == 1
        float centerDepth = texture2D(depthtex0, texcoord).r;

        // Skip calculations for the sky.
        if (centerDepth >= 0.9999) {
            gl_FragData[0] = vec4(color, 1.0);
            return;
        }

        // Fast cave exit check using camera light first.
        float camSkyLight = eyeBrightness.y / 240.0;
        float packedLight = texture2D(colortex1, texcoord).a * 255.0;
        float targetSkyLight = floor(packedLight / 16.0) / 15.0;
        float caveMask = smoothstep(0.01, 0.05, max(targetSkyLight, camSkyLight));

        if (caveMask <= 0.001) {
            gl_FragData[0] = vec4(color, 1.0);
            return;
        }

        vec4 viewPos = gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, centerDepth * 2.0 - 1.0, 1.0);
        viewPos /= viewPos.w;
        vec3 viewDir = normalize(viewPos.xyz);
        vec4 worldPos = gbufferModelViewInverse * viewPos;

        vec3 startPos = vec3(0.0);
        vec3 endPos = worldPos.xyz;
        float traceDist = min(length(endPos), float(GODRAY_MAX_DISTANCE));
        vec3 rayDir = normalize(endPos);

        int steps = int(GODRAY_STEPS);
        float stepLen = traceDist / float(steps);
        vec3 stepVec = rayDir * stepLen;

        float dither = getAnimatedDither(gl_FragCoord.xy, frameTimeCounter);
        
        // Shadow space setup.
        vec4 startShadowSpace = shadowProjection * (shadowModelView * vec4(startPos, 1.0));
        vec4 stepShadowSpace  = shadowProjection * (shadowModelView * vec4(stepVec, 0.0));
        vec4 currentShadowSpace = startShadowSpace + stepShadowSpace * dither;
        
        vec3 volumetricAccum = vec3(0.0);
        float rayBiasBase = SHADOW_BIAS * 0.002;

        for (int i = 0; i < steps; i++) {
            vec4 shadowSpacePos = currentShadowSpace / currentShadowSpace.w;
            
            float dist = length(shadowSpacePos.xy);
            float distortFactor = mix(1.0, dist, SHADOW_DISTORTION);
            shadowSpacePos.xy /= distortFactor;
            shadowSpacePos.z /= 3.0;
            shadowSpacePos = shadowSpacePos * 0.5 + 0.5;

            // Simple boundary check.
            if (all(greaterThan(shadowSpacePos.xyz, vec3(0.0))) && all(lessThan(shadowSpacePos.xyz, vec3(1.0)))) {
                float shadowDepth0 = texture2D(shadowtex0, shadowSpacePos.xy).r;
                float shadowDepth1 = texture2D(shadowtex1, shadowSpacePos.xy).r;
                float rayBias = rayBiasBase * distortFactor;

                if (shadowDepth1 >= shadowSpacePos.z - rayBias) {
                    // Optimized glass check.
                    if (shadowDepth0 < shadowSpacePos.z - rayBias) {
                        volumetricAccum += texture2D(shadowcolor0, shadowSpacePos.xy).rgb;
                    } else {
                        volumetricAccum += 1.0;
                    }
                }
            }
            currentShadowSpace += stepShadowSpace;
        }

        volumetricAccum /= float(steps);
        
        // Lighting logic (unchanged but cleaned for speed).
        vec3 rawSunDir = normalize(sunPosition);
        vec3 worldSunDir = (gbufferModelViewInverse * vec4(rawSunDir, 0.0)).xyz;
        vec3 lightSun, lightAmb; float shadowOp;
        getLightColors(worldSunDir, lightSun, lightAmb, shadowOp);

        float sunDotView = max(dot(viewDir, worldSunDir), 0.0);
        float glowFactor = pow(sunDotView, 6.0) * 0.9 + 0.1;
        float accumLuma = dot(volumetricAccum, vec3(0.299, 0.587, 0.114));
        
        float outdoorMask = 1.0 - smoothstep(float(GODRAY_OUTDOOR_MASK_START), float(GODRAY_OUTDOOR_MASK_END), accumLuma);
        float distanceFade = smoothstep(float(GODRAY_DISTANCE_FADE_START), float(GODRAY_DISTANCE_FADE_END), traceDist);
        float shaftContrast = pow(max(1.0 - accumLuma, 0.0), float(GODRAY_CONTRAST));
        float lookDownFade = smoothstep(-0.6, -0.1, viewDir.y);
        
        // Dim godrays dynamically based on rain strength.
        float rainDimmer = mix(1.0, float(GODRAY_RAIN_DIMMER), rainStrength);

        vec3 finalGodray = lightSun * volumetricAccum * shaftContrast * float(GODRAY_INDOOR_BOOST) * outdoorMask * distanceFade * lookDownFade * (float(GODRAY_INTENSITY) * rainDimmer) * glowFactor * getDirectionalFade(worldSunDir.y) * caveMask;
        
        // Soft add blending.
        color += finalGodray * (1.0 - color);
    #endif

    // Prevent negative colors to avoid NaN artifacts.
    color = max(color, vec3(0.0));

    gl_FragData[0] = vec4(color, 1.0);
}