// ============================================================================
// BASIC GEOMETRY & BLOCK OUTLINE VERTEX SHADER
// ============================================================================
#version 120

varying vec4 glcolor;

void main() {
    gl_Position = gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex;
    
    glcolor = gl_Color;
}