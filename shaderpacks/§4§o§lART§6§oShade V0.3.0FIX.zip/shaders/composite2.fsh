// ============================================================================
// BLOOM EXTRACTION PASS
// ============================================================================
#version 120

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"

varying vec2 texcoord;

void main() {
    #if ENABLE_BLOOM == 0
        /* DRAWBUFFERS:5 */
        gl_FragData[0] = vec4(0.0);
        return;
    #endif

    vec3 color = texture2D(colortex0, texcoord).rgb;
    float objectMask = texture2D(colortex3, texcoord).b;

    float luma = dot(color, vec3(0.299, 0.587, 0.114));
    float globalMask = smoothstep(float(GLOBAL_BLOOM_THRESHOLD) - 0.2, float(GLOBAL_BLOOM_THRESHOLD) + 0.2, luma);

    vec3 extractedBloom = color * (objectMask * float(OBJECT_BLOOM_INTENSITY) + globalMask * float(GLOBAL_BLOOM_INTENSITY));

    // Prevent negative colors to avoid NaN artifacts.
    extractedBloom = max(extractedBloom, vec3(0.0));

    /* DRAWBUFFERS:5 */
    gl_FragData[0] = vec4(extractedBloom, 1.0);
}