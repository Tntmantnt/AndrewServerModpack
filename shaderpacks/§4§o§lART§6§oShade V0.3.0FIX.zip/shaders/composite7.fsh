// ============================================================================
// TAA
// ============================================================================
#version 120
#extension GL_ARB_shader_texture_lod : enable

varying vec4 color;
varying vec2 texCoord;

#include "/lib/uniforms.glsl"
#include "/lib/taa.glsl" 

void main()
{
    vec3 sampledColor = texture2DLod(colortex5, texCoord, 0.0).rgb;
    float prevAlpha = texture2DLod(colortex6, texCoord, 0.0).a;

    vec4 prev = TemporalAA(sampledColor, prevAlpha); 

    // Prevent negative colors to avoid NaN artifacts.
    sampledColor = max(sampledColor, vec3(0.0));

    /*DRAWBUFFERS:56*/
    gl_FragData[0] = vec4(sampledColor, 1.0);
    gl_FragData[1] = prev; 
}