// ============================================================================
// PARTICLES RENDERING
// ============================================================================
#version 120
/* DRAWBUFFERS:013 */

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/sky.glsl"
#include "/lib/fog.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec4 viewPos;

void main() {
    // Base particle texture color.
    vec4 texColor = texture2D(gtexture, texcoord);
    vec4 albedo = vec4(texColor.rgb * glcolor.rgb, texColor.a);
    if (albedo.a < 0.1) discard;

    // Convert to linear space and apply Albedo Fix.
    vec3 linearAlbedo = pow(albedo.rgb, vec3(2.2));
    linearAlbedo *= 0.35; // Match terrain albedo fix.

    // Calculate world space sun direction.
    vec3 rawSunDir = normalize(sunPosition);
    vec3 worldSunDir = normalize((gbufferModelViewInverse * vec4(rawSunDir, 0.0)).xyz);

    // Fetch environment light colors.
    vec3 lightSunColor, lightAmbColor;
    float dummyShadowOpacity;
    getLightColors(worldSunDir, lightSunColor, lightAmbColor, dummyShadowOpacity);

    // Apply rain dimming strictly to sun and ambient, matching terrain logic.
    #ifdef RAIN_LIGHT_DIMMER
        float lightDimmer = mix(1.0, float(RAIN_LIGHT_DIMMER), rainStrength);
        lightSunColor *= lightDimmer;
        lightAmbColor *= lightDimmer;
    #endif

    // Unpack block and sky light values.
    float blockLight = lmcoord.x;
    float skyLight   = lmcoord.y;

    float skyLightCurve = pow(skyLight, float(CAVE_LIGHT_FALLOFF));
    vec3 caveBaseColor = vec3(CAVE_FOG_R, CAVE_FOG_G, CAVE_FOG_B);
    vec3 caveAmbientComp = caveBaseColor * float(MIN_CAVE_LIGHT) * (1.0 - skyLightCurve);

    // Calculate block torch attenuation.
    float torchAttenuation = (blockLight * blockLight) * sqrt(blockLight);
    vec3 torchIllumination = vec3(TORCH_R, TORCH_G, TORCH_B) * float(TORCH_INTENSITY) * torchAttenuation;
    
    // Combine ambient, direct, and block lighting without shadowing (typical for particles).
    vec3 customLighting = (lightAmbColor * skyLightCurve) + (lightSunColor * skyLight * 0.6) + caveAmbientComp + torchIllumination;

    // Apply custom lighting to linear particle color.
    vec3 finalColor = linearAlbedo * customLighting;
    
    // Return to sRGB space before fog and tint calculations.
    finalColor = pow(finalColor, vec3(1.0 / 2.2));
    
    // Apply distance fog to particles using the unified library.
    float distance = length(viewPos.xyz);
    vec3 worldViewDir = normalize((gbufferModelViewInverse * vec4(normalize(viewPos.xyz), 0.0)).xyz);
    
    // Calculate the TRUE world position dynamically to fix underwater particle bugs.
    vec3 realWorldPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz + cameraPosition;
    
    vec3 finalFogColor;
    float finalFogFactor;
    float borderFog;
    
    // Calculate and apply fog using library with the corrected position.
    applyFog(distance, realWorldPos, worldViewDir, worldSunDir, skyLightCurve, rainStrength, far, lightSunColor, finalFogColor, finalFogFactor, borderFog);
    
    // Discard particles completely hidden by border fog.
    if (borderFog < 0.001) {
        discard;
    }

    // Apply global hue shift tint BEFORE fog to match the terrain style perfectly.
    vec3 hueTint = vec3(HUE_SHIFT_R, HUE_SHIFT_G, HUE_SHIFT_B);
    vec3 normalizedTint = hueTint / max(dot(hueTint, vec3(0.333)), 0.001);
    finalColor = mix(finalColor, finalColor * normalizedTint, float(HUE_SHIFT_INTENSITY));

    // Final fog blend.
    finalColor = mix(finalFogColor, finalColor, finalFogFactor);
    
    // Lightmap packing and rimlight prevention.
    blockLight = clamp(lmcoord.x, 0.0, 1.0);
    float packedLight = (floor(blockLight * 15.0) + floor(skyLight * 15.0) * 16.0) / 255.0;
    vec3 dummyNormal = vec3(0.0, 1.0, 0.0);
    
    // Prevent negative colors to avoid NaN artifacts.
    finalColor = max(finalColor, vec3(0.0));

    /* DRAWBUFFERS:0123 */
    gl_FragData[0] = vec4(finalColor, albedo.a);
    gl_FragData[1] = vec4(dummyNormal * 0.5 + 0.5, packedLight);
    
    // Fill colortex2 with empty data to prevent SSR issues.
    gl_FragData[2] = vec4(0.0);
    
    // Write absolute rimlight exclusion flag to the GREEN channel of colortex3.
    gl_FragData[3] = vec4(0.0, 1.0, 0.0, 1.0);
}