// ============================================================================
// BASIC SKY AND CELESTIAL GLOW
// ============================================================================
#version 120

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/sky.glsl"

varying vec3 viewVector;

float getTemporalWorldDither(vec3 worldDir, int frame) {
    // Scale world direction for high-frequency noise.
    vec3 p3 = fract(worldDir * 4000.0 * 0.1031);
    
    // Apply discrete temporal jitter using the Golden Ratio to prevent scrolling.
    float temporalOffset = fract(float(frame % 16) * 0.6180339887);
    p3 += temporalOffset;
    
    // Calculate the final pseudo-random hash.
    p3 += dot(p3, p3.yzx + 33.33);
    
    return fract((p3.x + p3.y) * p3.z);
}

void main() {
    vec3 rawSunDir = normalize(sunPosition);
    vec3 worldSunDir = normalize((gbufferModelViewInverse * vec4(rawSunDir, 0.0)).xyz);
    vec3 worldViewDir = normalize((gbufferModelViewInverse * vec4(viewVector, 0.0)).xyz);
    
    vec3 zenithCol, horizonCol;
    getSkyColors(worldViewDir, worldSunDir, rainStrength, zenithCol, horizonCol);

    float height = max(dot(normalize(viewVector), normalize(upPosition)), 0.0);
    float gradient = pow(height, SKY_GRADIENT);
    vec3 skyColor = mix(horizonCol, zenithCol, gradient);

    // Celestial glow calculation
    float sunDot = dot(worldViewDir, worldSunDir);
    float moonDot = dot(worldViewDir, -worldSunDir); 

    float sunGlow  = pow(max(sunDot, 0.0), float(SUN_GLOW_SPREAD)) * float(SUN_GLOW_POWER);
    float moonGlow = pow(max(moonDot, 0.0), float(MOON_GLOW_SPREAD)) * float(MOON_GLOW_POWER);

    bool isSunrise = checkIsSunrise();
    float sVis, nVis, oVis;
    getTransitionFactor(worldSunDir.y, isSunrise, sVis, nVis, oVis);
    
    vec3 sunriseColor = vec3(SUN_SUNRISE_R, SUN_SUNRISE_G, SUN_SUNRISE_B);
    vec3 sunsetColor  = vec3(SUN_SUNSET_R, SUN_SUNSET_G, SUN_SUNSET_B);
    vec3 baseCelestialColor = isSunrise ? sunriseColor : sunsetColor;
    
    float skySat = isSunrise ? float(SUN_SUNRISE_SATURATION) : float(SUN_SUNSET_SATURATION);
    vec3 skyTwiColor = applySaturation(baseCelestialColor, skySat);

    vec3 cSunBase = vec3(SUN_R, SUN_G, SUN_B);
    vec3 sunGlowColor = (cSunBase * sVis) + (skyTwiColor * oVis);
    vec3 moonGlowColor = vec3(MOON_R, MOON_G, MOON_B); 

    float skyDim = mix(1.0, 1.0 - float(SKY_RAIN_COVERAGE), rainStrength);
    skyColor += (sunGlowColor * sunGlow) * skyDim;
    skyColor += (moonGlowColor * moonGlow) * skyDim;

    float dither = getTemporalWorldDither(worldViewDir, frameCounter);
    
    float ditherAmplitude = mix(0.005, 0.015, nVis); 
    skyColor += (dither - 0.5) * ditherAmplitude;

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(skyColor, 1.0);
}