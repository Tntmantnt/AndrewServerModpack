// ============================================================================
// BLOOM HORIZONTAL PASS
// ============================================================================
#version 120

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"

varying vec2 texcoord;

float linearizeDepth(float d) {
    return (near * far) / (far - d * (far - near));
}

void main() {
    #if ENABLE_BLOOM == 0
        /* DRAWBUFFERS:4 */
        gl_FragData[0] = vec4(0.0);
        return;
    #endif

    float centerDepth = texture2D(depthtex0, texcoord).r;
    float dist = (centerDepth >= 1.0) ? 256.0 : linearizeDepth(centerDepth);
    float distScale = clamp(5.0 / max(dist, 0.5), 0.05, 5.0);

    vec2 direction = vec2(1.0 / viewWidth, 0.0);
    float max_radius = float(BLOOM_RADIUS) * 15.0 * distScale;
    float stepDist = max_radius / float(BLOOM_STEPS);
    
    float sigma = float(BLOOM_STEPS) * 0.5;
    float sigmaSq2Inv = 1.0 / (2.0 * sigma * sigma);
    
    vec3 result = texture2D(colortex5, texcoord).rgb;
    float totalWeight = 1.0; 
    
    for (int i = 1; i <= BLOOM_STEPS; i++) {
        float iF = float(i);
        float weight = exp(-(iF * iF) * sigmaSq2Inv);
        
        vec2 offsetUV = direction * (iF * stepDist);
        vec2 uv1 = clamp(texcoord + offsetUV, 0.001, 0.999);
        vec2 uv2 = clamp(texcoord - offsetUV, 0.001, 0.999);
        
        result += (texture2D(colortex5, uv1).rgb + texture2D(colortex5, uv2).rgb) * weight;
        totalWeight += weight * 2.0;
    }

    // Prevent negative colors to avoid NaN artifacts.
    result = max(result, vec3(0.0));

    /* DRAWBUFFERS:4 */
    gl_FragData[0] = vec4(result / totalWeight, 1.0);
}