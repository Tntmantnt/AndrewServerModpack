// ============================================================================
// FIRST PERSON HAND RENDERING
// ============================================================================
#version 120

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/sky.glsl"
#include "/lib/shadow_filter.glsl"

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec4 viewPos;
varying vec2 lmcoord;

void main() {
    vec4 texColor = texture2D(gtexture, texcoord);
    vec4 albedo = vec4(texColor.rgb * glcolor.rgb, texColor.a);

    #if AMBIENT_OCCLUSION == 1
        // Interpolates between flat color and full vanilla AO.
        float ao_opacity = mix(1.0, glcolor.a, float(VANILLA_AO_INTENSITY));
        albedo.rgb *= ao_opacity; 
    #elif AMBIENT_OCCLUSION == 2
        // Custom ao will be implemented here.
    #endif
	
	// Convert to linear space and apply Albedo Fix.
    vec3 linearAlbedo = pow(albedo.rgb, vec3(2.2));
    linearAlbedo *= 0.95; // Match terrain albedo fix.
    
    vec3 n = normalize(normal);
    vec3 rawSunDir = normalize(sunPosition);
    vec3 worldSunDir = (gbufferModelViewInverse * vec4(rawSunDir, 0.0)).xyz;
    
    // Synchronize exact sun/moon light vector with OptiFine.
    vec3 l = worldSunDir.y > 0.0 ? rawSunDir : -rawSunDir;
    
    // Calculate surface illumination dot product.
    float NdotL = max(dot(n, l), 0.0);
    
    // Fetch dynamic sun and ambient colors from library.
    vec3 lightSunColor, lightAmbColor;
    float currentShadowOpacity;
    getLightColors(worldSunDir, lightSunColor, lightAmbColor, currentShadowOpacity);

    // Apply global dimming during rain.
    float lightDimmer = mix(1.0, float(RAIN_LIGHT_DIMMER), rainStrength);
    lightSunColor *= lightDimmer;
    lightAmbColor *= lightDimmer;
	
    float blockLight = lmcoord.x; 
    float skyLight   = lmcoord.y;
    
    // Dynamic handheld light computation.
    #if HAND_DYNAMIC_LIGHTING == 1
        // First person hand is always relative to camera.
        float handLight = clamp(1.0 - (length(viewPos.xyz) / float(DYNAMIC_LIGHT_RADIUS)), 0.0, 1.0) * (float(heldBlockLightValue) / 15.0);
        blockLight = max(blockLight, handLight);
    #endif

    // ========================================================================
    // SHADOW MAPPING AND ILLUMINATION
    // ========================================================================
    float shadow = 1.0;

    #if ENABLE_SHADOWS == 1
        if (NdotL > 0.0) {
            vec4 worldPosShadow = gbufferModelViewInverse * viewPos;
            vec4 shadowSpacePos = shadowModelView * worldPosShadow;
            shadowSpacePos = shadowProjection * shadowSpacePos;
            shadowSpacePos /= shadowSpacePos.w;
            
            float dist = length(shadowSpacePos.xy);
            float distortFactor = mix(1.0, dist, SHADOW_DISTORTION);
            shadowSpacePos.xy /= distortFactor;
            shadowSpacePos.z /= 3.0;

            if (abs(shadowSpacePos.x) < 0.99 && abs(shadowSpacePos.y) < 0.99) {
                shadowSpacePos = shadowSpacePos * 0.5 + 0.5;
                shadow = getHardShadow(shadowtex0, shadowSpacePos.xyz, NdotL, distortFactor);
            }
        }
    #endif
    
    // Apply shadow opacity to direct lighting.
    float totalShadow = NdotL * shadow;
    // Maintain minimum ambient light within shadows.
    float lightIntensity = mix(1.0 - currentShadowOpacity, 1.0, totalShadow);
    
    // Cave isolation to prevent daylight leaking.
    float skyLightCurve = pow(skyLight, float(CAVE_LIGHT_FALLOFF));
    float sunlightForce = lightIntensity * skyLightCurve;
    vec3 sunlightComp = linearAlbedo * lightSunColor * sunlightForce;
    
    // Apply sky ambient lighting based on exposure.
    vec3 skyAmbientComp = linearAlbedo * lightAmbColor * skyLightCurve;
    // Apply constant cave ambient lighting.
    vec3 caveBaseColor = vec3(CAVE_FOG_R, CAVE_FOG_G, CAVE_FOG_B);
    vec3 caveAmbientComp = linearAlbedo * caveBaseColor * float(MIN_CAVE_LIGHT) * (1.0 - skyLightCurve);
    
    // Combine sky and cave ambient lighting.
    vec3 ambientComp = skyAmbientComp + caveAmbientComp;

    float torchAttenuation = (blockLight * blockLight) * sqrt(blockLight);
    vec3 torchColor = vec3(TORCH_R, TORCH_G, TORCH_B) * TORCH_INTENSITY;
    vec3 torchIllumination = linearAlbedo * torchColor * torchAttenuation;
    
    vec3 finalColor = sunlightComp + ambientComp + torchIllumination;

    // Return to sRGB space.
    finalColor = pow(finalColor, vec3(1.0 / 2.2));

    // Fog is skipped for the hand model as it is always close to the camera.

    // Pack lighting data for rim light mask.
    float lightMask = clamp(sunlightForce + torchAttenuation, 0.0, 1.0);
    float lSun = clamp(sunlightForce, 0.0, 1.0);
    float lBlock = clamp(blockLight, 0.0, 1.0);
    float packedLight = (floor(lBlock * 15.0) + floor(lSun * 15.0) * 16.0) / 255.0;
    
    // Check if item emits dynamic light for bloom.
    bool is_emissive_entity = (lmcoord.x > 0.9);
    // Mask emissive items based on texture luminance.
    float luma = dot(albedo.rgb, vec3(0.299, 0.587, 0.114));
    float luma_mask = smoothstep(float(BLOOM_COLOR_DETECTION) - 0.2, float(BLOOM_COLOR_DETECTION) + 0.2, luma);
    
    float emissive_flag = (is_emissive_entity ? 1.0 : 0.0) * luma_mask;
    
    // Prevent negative colors to avoid NaN artifacts.
    finalColor = max(finalColor, vec3(0.0));

    /* DRAWBUFFERS:0123 */
    gl_FragData[0] = vec4(finalColor, albedo.a);
    gl_FragData[1] = vec4(normal * 0.5 + 0.5, packedLight);
    gl_FragData[2] = vec4(0.0, 0.0, 0.0, 0.0);
    gl_FragData[3] = vec4(0.0, 0.0, emissive_flag, 1.0); 
}