// ============================================================================
// FINAL OUTPUT AND DITHERING
// ============================================================================
#version 120
#extension GL_ARB_shader_texture_lod : enable

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/tonemap.glsl"

varying vec2 texcoord;

// Dynamic macro: read the correct buffer based on TAA state
#if ENABLE_TAA == 1
    #define CURRENT_BUFFER colortex5
#else
    #define CURRENT_BUFFER colortex0
#endif

// --- CAS (AMD Contrast Adaptive Sharpening) ---
// Recovers details lost by TAA without creating ugly halos
#if SHARPENING == 1
void SharpenFilter(inout vec3 color, vec2 textureCoord) {
    vec2 texOffset = vec2(1.0 / viewWidth, 1.0 / viewHeight);

    // Cross and diagonal sampling (9 pixels total)
    vec3 a = texture2D(CURRENT_BUFFER, textureCoord + texOffset * vec2(-1.0, -1.0)).rgb;
    vec3 b = texture2D(CURRENT_BUFFER, textureCoord + texOffset * vec2( 0.0, -1.0)).rgb;
    vec3 c = texture2D(CURRENT_BUFFER, textureCoord + texOffset * vec2( 1.0, -1.0)).rgb;
    vec3 d = texture2D(CURRENT_BUFFER, textureCoord + texOffset * vec2(-1.0,  0.0)).rgb;
    vec3 e = color; // Center pixel
    vec3 f = texture2D(CURRENT_BUFFER, textureCoord + texOffset * vec2( 1.0,  0.0)).rgb;
    vec3 g = texture2D(CURRENT_BUFFER, textureCoord + texOffset * vec2(-1.0,  1.0)).rgb;
    vec3 h = texture2D(CURRENT_BUFFER, textureCoord + texOffset * vec2( 0.0,  1.0)).rgb;
    vec3 i = texture2D(CURRENT_BUFFER, textureCoord + texOffset * vec2( 1.0,  1.0)).rgb;

    // Calculate local contrast amplitude
    vec3 mnRGB = min(min(min(d, e), min(f, b)), h) + min(min(min(a, g), c), i);
    vec3 mxRGB = max(max(max(d, e), max(f, b)), h) + max(max(max(a, g), c), i);

    vec3 rcpMxRGB = 1.0 / mxRGB;
    vec3 ampRGB = clamp(min(mnRGB, 2.0 - mxRGB) * rcpMxRGB, 0.0, 1.0);

    ampRGB = inversesqrt(ampRGB);
    
    // Apply strength from SHARPEN_STRENGTH slider
    float peak = 8.0 - 3.0 * float(SHARPEN_STRENGTH);
    vec3 wRGB = -1.0 / (ampRGB * peak);
    vec3 rcpWeightRGB = 1.0 / (1.0 + 4.0 * wRGB);
    
    // color = clamp(((b + d + f + h) * wRGB + e) * rcpWeightRGB, 0.0, 1.0);
    color = max(((b + d + f + h) * wRGB + e) * rcpWeightRGB, 0.0);
}
#endif

void main() {
    // 1. Read image
    vec3 color = texture2D(CURRENT_BUFFER, texcoord).rgb;
    
    // 2. Apply dynamic sharpening filter
    #if SHARPENING == 1
        SharpenFilter(color, texcoord);
    #endif
    
    // 3. Final tonemapping
    color = applyTonemap(color);
    
    gl_FragColor = vec4(color, 1.0);
}

#include "/lib/buffers.glsl"