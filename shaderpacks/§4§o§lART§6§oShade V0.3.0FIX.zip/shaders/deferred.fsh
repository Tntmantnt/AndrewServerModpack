// ============================================================================
// CLOUDS
// ============================================================================
#version 120

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/clouds.glsl"
#include "/lib/sky.glsl"
#include "/lib/fog.glsl"

varying vec2 texcoord;

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    float depth = texture2D(depthtex0, texcoord).r;
    
    vec4 viewPos = gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    viewPos /= viewPos.w;
    vec3 worldDir = normalize((gbufferModelViewInverse * vec4(viewPos.xyz, 0.0)).xyz);
    
    float maxDist = (depth == 1.0) ? 1000000.0 : length(viewPos.xyz);
    vec3 rawSunDir = normalize(sunPosition);
    vec3 worldSunDir = normalize((gbufferModelViewInverse * vec4(rawSunDir, 0.0)).xyz);

    vec3 zenithCol, horizonCol;
    getSkyColors(worldDir, worldSunDir, rainStrength, zenithCol, horizonCol);
    
    // Render and blend clouds.
    vec4 cloudData = renderClouds(worldDir, worldSunDir, frameTimeCounter, cameraPosition, zenithCol, horizonCol, maxDist);
    color.rgb = color.rgb * (1.0 - cloudData.a) + cloudData.rgb;
    
    // Hide the sky and clouds behind the underwater fog when submerged.
    if (isEyeInWater == 1 && depth == 1.0) {
        vec3 lightSunColor, lightAmbColor;
        float dummyShadowOpacity;
        getLightColors(worldSunDir, lightSunColor, lightAmbColor, dummyShadowOpacity);
        
        vec3 finalFogColor;
        float finalFogFactor;
        float borderFog;
        
        // Calculate the exact world position where the wall of water is located.
        float borderEnd = far * float(UNDERWATER_BORDER_FOG_END);
        vec3 skyWorldPos = cameraPosition + worldDir * borderEnd;
        
        // Apply infinite distance fog using the correct depth of the background.
        applyFog(far * 2.0, skyWorldPos, worldDir, worldSunDir, 1.0, rainStrength, far, lightSunColor, finalFogColor, finalFogFactor, borderFog);
        
        // Force the background to be exactly the underwater fog color.
        color.rgb = finalFogColor;
    }
    
    // Prevent negative colors to avoid NaN artifacts.
    color = max(color, vec3(0.0));
    
    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}